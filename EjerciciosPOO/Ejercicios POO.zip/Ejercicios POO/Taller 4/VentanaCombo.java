import javax.swing.*;

public class VentanaCombo extends JFrame {

    private JComboBox<String> cboColores;
    private JLabel etiResultado;

    public VentanaCombo() {
        initComponents();
    }

    private void initComponents() {
        String[] colores = {"Rojo", "Verde", "Azul"};
        cboColores = new JComboBox<>(colores);
        etiResultado = new JLabel(" ");
        cboColores.setEditable(true);
        cboColores.addActionListener(e -> mostrarColor());

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Colores Combo");
        setLayout(null);

        cboColores.setBounds(20, 20, 120, 30);
        etiResultado.setBounds(20, 70, 250, 30);
        etiResultado.setBorder(BorderFactory.createEtchedBorder());

        add(cboColores);
        add(etiResultado);

        setSize(300, 160);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void mostrarColor() {
        String mensaje = "El color elegido es ";
        mensaje += cboColores.getSelectedItem().toString();
        etiResultado.setText(mensaje);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new VentanaCombo());
    }
}
