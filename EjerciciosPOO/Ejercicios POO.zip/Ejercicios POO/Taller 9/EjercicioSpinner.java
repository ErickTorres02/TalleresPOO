import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;

public class EjercicioSpinner extends JFrame {
    private JSpinner spiValor;
    private JLabel etiValor;

    public EjercicioSpinner() {
        // Configuración básica de la ventana
        setTitle("Ejercicio con JSpinner");
        setSize(300, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout(FlowLayout.CENTER, 20, 20));
        getContentPane().setBackground(new Color(240, 240, 240));

        // Configuración del modelo del Spinner
        SpinnerNumberModel spinnerModel = new SpinnerNumberModel();
        spinnerModel.setMinimum(0);
        spinnerModel.setMaximum(10);
        spinnerModel.setStepSize(2);
        spinnerModel.setValue(4); // Valor inicial solicitado

        // Creación del JSpinner con el modelo configurado
        spiValor = new JSpinner(spinnerModel);
        
        // Personalización del aspecto del Spinner
        JSpinner.DefaultEditor editor = (JSpinner.DefaultEditor)spiValor.getEditor();
        editor.getTextField().setColumns(3);
        editor.getTextField().setHorizontalAlignment(JTextField.CENTER);

        // Creación de la etiqueta con borde
        etiValor = new JLabel("El valor es: 4", SwingConstants.CENTER);
        etiValor.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        etiValor.setPreferredSize(new Dimension(200, 30));
        etiValor.setFont(new Font("Arial", Font.PLAIN, 14));
        etiValor.setOpaque(true);
        etiValor.setBackground(Color.WHITE);

        // Añadir componentes a la ventana
        add(spiValor);
        add(etiValor);

        // Añadir listener para el cambio de valor del Spinner
        spiValor.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                etiValor.setText("El valor es: " + spiValor.getValue().toString());
            }
        });

        // Añadir padding alrededor de los componentes
        ((JComponent) getContentPane()).setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            EjercicioSpinner ventana = new EjercicioSpinner();
            ventana.setVisible(true);
        });
    }
}