public class Main {
    public static void main(String[] args) {
       
        Rectangulo miRectangulo = new Rectangulo();
        
        
        System.out.println("Base inicial: " + miRectangulo.getBase());
        System.out.println("Altura inicial: " + miRectangulo.getAltura());
        System.out.println("Área inicial: " + miRectangulo.getArea());
        System.out.println("Perímetro inicial: " + miRectangulo.getPerimetro());
        
       
        miRectangulo.setBase(30);
        miRectangulo.setAltura(40);
        
        System.out.println("\nDespués de modificar:");
        System.out.println("Base: " + miRectangulo.getBase());
        System.out.println("Altura: " + miRectangulo.getAltura());
        System.out.println("Área: " + miRectangulo.getArea());
        System.out.println("Perímetro: " + miRectangulo.getPerimetro());
        
       
        miRectangulo.cuadrar();
        
        
        System.out.println("\nDespués de cuadrar:");
        System.out.println("Base: " + miRectangulo.getBase());
        System.out.println("Altura: " + miRectangulo.getAltura());
        System.out.println("Área: " + miRectangulo.getArea());
        System.out.println("Perímetro: " + miRectangulo.getPerimetro());
    }
}