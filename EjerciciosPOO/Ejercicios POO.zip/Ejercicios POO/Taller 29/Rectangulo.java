public class Rectangulo {
    // Propiedades
    private double base;
    private double altura;

    // Constructor
    public Rectangulo() {
        this.base = 100;
        this.altura = 50;
    }

    // Métodos set
    public void setBase(double base) {
        this.base = base;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    // Métodos get
    public double getBase() {
        return this.base;
    }

    public double getAltura() {
        return this.altura;
    }

    public double getArea() {
        return this.base * this.altura;
    }

    public double getPerimetro() {
        return 2 * (this.base + this.altura);
    }

    // Método Cuadrar
    public void cuadrar() {
        this.altura = this.base;
    }
}