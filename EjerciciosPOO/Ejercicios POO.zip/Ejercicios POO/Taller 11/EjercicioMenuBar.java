import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class EjercicioMenuBar extends JFrame {
    private JMenuBar barraMenus;
    private JMenu menuArchivo, menuEdicion, menuInsertar;
    private JMenuItem menuItemAbrir, menuItemGuardar, menuItemSalir;
    private JMenu menuColores;
    private JMenuItem menuItemRojo, menuItemVerde, menuItemAzul;

    public EjercicioMenuBar() {
        // Configuración básica de la ventana
        setTitle("Ejercicio con Barra de Menús");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(Color.WHITE);

        // Creación de la barra de menús
        barraMenus = new JMenuBar();
        setJMenuBar(barraMenus);

        // Menú Archivo
        menuArchivo = new JMenu("Archivo");
        barraMenus.add(menuArchivo);
        
        menuItemAbrir = new JMenuItem("Abrir");
        menuItemGuardar = new JMenuItem("Guardar");
        menuItemSalir = new JMenuItem("Salir");
        
        menuArchivo.add(menuItemAbrir);
        menuArchivo.add(menuItemGuardar);
        menuArchivo.add(new JSeparator());
        menuArchivo.add(menuItemSalir);

        // Menú Edición
        menuEdicion = new JMenu("Edición");
        barraMenus.add(menuEdicion);
        
        menuColores = new JMenu("Colores");
        menuEdicion.add(menuColores);
        
        menuItemRojo = new JMenuItem("Rojo");
        menuItemVerde = new JMenuItem("Verde");
        menuItemAzul = new JMenuItem("Azul");
        
        menuColores.add(menuItemRojo);
        menuColores.add(menuItemVerde);
        menuColores.add(menuItemAzul);

        // Menú Insertar
        menuInsertar = new JMenu("Insertar");
        barraMenus.add(menuInsertar);

        // Asignar acciones a los menús
        menuItemRojo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                getContentPane().setBackground(Color.RED);
            }
        });
        
        menuItemVerde.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                getContentPane().setBackground(Color.GREEN);
            }
        });
        
        menuItemAzul.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                getContentPane().setBackground(Color.BLUE);
            }
        });
        
        menuItemSalir.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            EjercicioMenuBar ventana = new EjercicioMenuBar();
            ventana.setVisible(true);
        });
    }
}