import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class EjercicioScrollBars extends JFrame {
    private JScrollBar desValor;
    private JLabel etiValor;

    public EjercicioScrollBars() {
        // Configuración básica de la ventana
        setTitle("Ejercicio con JScrollBar");
        setSize(500, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(20, 20));
        getContentPane().setBackground(new Color(240, 240, 240));

        // Creación y configuración de la barra de desplazamiento
        desValor = new JScrollBar(JScrollBar.HORIZONTAL, 70, 5, 50, 150);
        
        // Configuración de propiedades adicionales
        desValor.setUnitIncrement(2);
        desValor.setBlockIncrement(20);

        // Creación de la etiqueta con borde
        etiValor = new JLabel("El valor es: 70", SwingConstants.CENTER);
        etiValor.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        etiValor.setPreferredSize(new Dimension(400, 40));
        etiValor.setFont(new Font("Arial", Font.BOLD, 14));
        etiValor.setOpaque(true);
        etiValor.setBackground(Color.WHITE);

        // Añadir componentes a la ventana
        add(desValor, BorderLayout.CENTER);
        add(etiValor, BorderLayout.SOUTH);

        // Añadir listener para el cambio de valor de la barra
        desValor.addAdjustmentListener(new AdjustmentListener() {
            public void adjustmentValueChanged(AdjustmentEvent e) {
                etiValor.setText("El valor es: " + desValor.getValue());
            }
        });

        // Añadir padding alrededor de los componentes
        ((JComponent) getContentPane()).setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            EjercicioScrollBars ventana = new EjercicioScrollBars();
            ventana.setVisible(true);
        });
    }
}