import javax.swing.*;
import java.awt.*;

public class LayoutPaneles extends JFrame {

    public LayoutPaneles() {
        setTitle("Ejemplo Layouts y Paneles");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        
        JPanel panelTitulo = new JPanel(new FlowLayout());
        JLabel label1 = new JLabel("Sistema de Gestión");
        JLabel label2 = new JLabel("Versión 1.0");
        label1.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        label2.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        panelTitulo.add(label1);
        panelTitulo.add(label2);
        add(panelTitulo, BorderLayout.NORTH);

        
        JPanel panelBotonera = new JPanel(null);
        panelBotonera.setPreferredSize(new Dimension(150, 0));
        
        JButton btn1 = new JButton("Opción 1");
        JButton btn2 = new JButton("Opción 2");
        JButton btn3 = new JButton("Opción 3");
        JButton btn4 = new JButton("Opción 4");
        
        btn1.setBounds(20, 20, 110, 30);
        btn2.setBounds(20, 70, 110, 30);
        btn3.setBounds(20, 120, 110, 30);
        btn4.setBounds(20, 170, 110, 30);
        
        panelBotonera.add(btn1);
        panelBotonera.add(btn2);
        panelBotonera.add(btn3);
        panelBotonera.add(btn4);
        add(panelBotonera, BorderLayout.WEST);

       
        JPanel panelVerificacion = new JPanel(null);
        panelVerificacion.setPreferredSize(new Dimension(150, 0));
        
        JCheckBox check1 = new JCheckBox("Opción A");
        JCheckBox check2 = new JCheckBox("Opción B");
        JCheckBox check3 = new JCheckBox("Opción C");
        JCheckBox check4 = new JCheckBox("Opción D");
        
        check1.setBounds(20, 20, 110, 30);
        check2.setBounds(20, 60, 110, 30);
        check3.setBounds(20, 100, 110, 30);
        check4.setBounds(20, 140, 110, 30);
        
        panelVerificacion.add(check1);
        panelVerificacion.add(check2);
        panelVerificacion.add(check3);
        panelVerificacion.add(check4);
        add(panelVerificacion, BorderLayout.EAST);

        
        JPanel panelDatos = new JPanel(new GridLayout(2, 2));
        
        JPanel panelEtiqueta1 = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JPanel panelCuadro1 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JPanel panelEtiqueta2 = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JPanel panelCuadro2 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        
        panelEtiqueta1.add(new JLabel("Nombre:"));
        panelCuadro1.add(new JTextField(15));
        panelEtiqueta2.add(new JLabel("Apellido:"));
        panelCuadro2.add(new JTextField(15));
        
        panelDatos.add(panelEtiqueta1);
        panelDatos.add(panelCuadro1);
        panelDatos.add(panelEtiqueta2);
        panelDatos.add(panelCuadro2);
        add(panelDatos, BorderLayout.CENTER);

        
        JPanel panelEstado = new JPanel(null);
        panelEstado.setPreferredSize(new Dimension(0, 50));
        
        JLabel estado1 = new JLabel("Estado:");
        JLabel estado2 = new JLabel("Conectado");
        JLabel estado3 = new JLabel("Usuario: Admin");
        
        estado1.setBounds(400, 10, 100, 30);
        estado2.setBounds(500, 10, 100, 30);
        estado3.setBounds(600, 10, 150, 30);
        
        panelEstado.add(estado1);
        panelEstado.add(estado2);
        panelEstado.add(estado3);
        add(panelEstado, BorderLayout.SOUTH);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            LayoutPaneles ventana = new LayoutPaneles();
            ventana.setVisible(true);
        });
    }
}