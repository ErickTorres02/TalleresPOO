

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class DialogoFecha extends JDialog {
    private JTextField txtDia = new JTextField(2);
    private JTextField txtMes = new JTextField(2);
    private JTextField txtAnio = new JTextField(4);
    private JButton btnAceptar = new JButton("Aceptar");
    private JButton btnCancelar = new JButton("Cancelar");
    
    private int dia = 0;
    private int mes = 0;
    private int anio = 0;
    private int botonPulsado = 1; 

    public DialogoFecha(JFrame parent) {
        super(parent, "Introducir Fecha", true);
        setSize(300, 150);
        setLocationRelativeTo(parent);
        setLayout(new GridLayout(4, 1, 5, 5));
        
        
        JPanel panelFecha = new JPanel(new FlowLayout());
        panelFecha.add(new JLabel("Día:"));
        panelFecha.add(txtDia);
        panelFecha.add(new JLabel("Mes:"));
        panelFecha.add(txtMes);
        panelFecha.add(new JLabel("Año:"));
        panelFecha.add(txtAnio);
        
       
        JPanel panelBotones = new JPanel(new FlowLayout());
        panelBotones.add(btnAceptar);
        panelBotones.add(btnCancelar);
        
        
        btnAceptar.addActionListener(this::accionAceptar);
        btnCancelar.addActionListener(this::accionCancelar);
        
        
        add(panelFecha);
        add(panelBotones);
    }

    private void accionAceptar(ActionEvent e) {
        try {
            dia = Integer.parseInt(txtDia.getText());
            mes = Integer.parseInt(txtMes.getText());
            anio = Integer.parseInt(txtAnio.getText());
            botonPulsado = 0; 
            dispose();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, 
                "Por favor ingrese valores numéricos válidos",
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void accionCancelar(ActionEvent e) {
        botonPulsado = 1; 
        dispose();
    }

    public String getFecha() {
        return dia + "/" + mes + "/" + anio;
    }

    public String getFechaLarga() {
        String[] meses = {"Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
                         "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"};
        String mesNombre = (mes >= 1 && mes <= 12) ? meses[mes-1] : "Mes inválido";
        return dia + " de " + mesNombre + " de " + anio;
    }

    public int getBotonPulsado() {
        return botonPulsado;
    }
}