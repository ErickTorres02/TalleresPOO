

import java.awt.*;
import javax.swing.*;

public class VentanaPrincipal extends JFrame {
    private DialogoFecha dialogoFecha;
    private JLabel etiFechaCorta;
    private JLabel etiFechaLarga;

    public VentanaPrincipal() {
        setTitle("Diálogo de Fechas Personalizado");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(3, 1, 10, 10));
        
        
        dialogoFecha = new DialogoFecha(this);
        
       
        JButton btnMostrarDialogo = new JButton("Seleccionar Fecha");
        etiFechaCorta = crearEtiquetaConBorde();
        etiFechaLarga = crearEtiquetaConBorde();
        
       
        btnMostrarDialogo.addActionListener(e -> mostrarDialogoFecha());
        
        
        add(btnMostrarDialogo);
        add(etiFechaCorta);
        add(etiFechaLarga);
    }

    private JLabel crearEtiquetaConBorde() {
        JLabel etiqueta = new JLabel(" ", SwingConstants.CENTER);
        etiqueta.setBorder(BorderFactory.createTitledBorder("Fecha"));
        etiqueta.setPreferredSize(new Dimension(350, 50));
        return etiqueta;
    }

    private void mostrarDialogoFecha() {
        dialogoFecha.setVisible(true);
        
        if (dialogoFecha.getBotonPulsado() == 0) { // Aceptar
            etiFechaCorta.setText("Fecha corta: " + dialogoFecha.getFecha());
            etiFechaLarga.setText("Fecha larga: " + dialogoFecha.getFechaLarga());
        } else {
            etiFechaCorta.setText("Operación cancelada");
            etiFechaLarga.setText("No se seleccionó fecha");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            VentanaPrincipal ventana = new VentanaPrincipal();
            ventana.setVisible(true);
        });
    }
}