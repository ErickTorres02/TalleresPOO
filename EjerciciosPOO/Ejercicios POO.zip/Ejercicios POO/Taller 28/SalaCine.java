public class SalaCine {
    
    private int aforo;
    private int ocupadas;
    private String pelicula;
    private double entrada;

    
    public SalaCine() {
        this.aforo = 100;
        this.ocupadas = 0;
        this.pelicula = "";
        this.entrada = 5.00;
    }

    
    public void setAforo(int aforo) {
        this.aforo = aforo;
    }

    public void setOcupadas(int ocupadas) {
        this.ocupadas = ocupadas;
    }

    public void setLibres(int libres) {
        this.ocupadas = this.aforo - libres;
    }

    public void setPelicula(String pelicula) {
        this.pelicula = pelicula;
    }

    public void setEntrada(double entrada) {
        this.entrada = entrada;
    }

    
    public int getAforo() {
        return this.aforo;
    }

    public int getOcupadas() {
        return this.ocupadas;
    }

    public int getLibres() {
        return this.aforo - this.ocupadas;
    }

    public double getPorcentaje() {
        return (this.ocupadas * 100.0) / this.aforo;
    }

    public double getIngresos() {
        return this.ocupadas * this.entrada;
    }

    public String getPelicula() {
        return this.pelicula;
    }

    public double getEntrada() {
        return this.entrada;
    }

    
    public void vaciar() {
        this.ocupadas = 0;
        this.pelicula = "";
    }

    public void entraUno() {
        if (this.ocupadas < this.aforo) {
            this.ocupadas++;
        }
    }
}