public class Main {
    public static void main(String[] args) {
        
        SalaCine central = new SalaCine();
        SalaCine salaVO = new SalaCine();

        
        central.setPelicula("Avengers: Endgame");
        central.setEntrada(8.50);
        
        
        salaVO.setAforo(50);
        salaVO.setPelicula("Metrópolis");
        salaVO.setEntrada(3.00);

        
        for (int i = 0; i < 75; i++) {
            central.entraUno();
        }
        for (int i = 0; i < 30; i++) {
            salaVO.entraUno();
        }

        System.out.println("Sala Central:");
        System.out.println("Película: " + central.getPelicula());
        System.out.println("Ocupación: " + central.getOcupadas() + "/" + central.getAforo());
        System.out.println("Porcentaje: " + central.getPorcentaje() + "%");
        System.out.println("Ingresos: " + central.getIngresos() + "€");

        System.out.println("\nSala Versión Original:");
        System.out.println("Película: " + salaVO.getPelicula());
        System.out.println("Ocupación: " + salaVO.getOcupadas() + "/" + salaVO.getAforo());
        System.out.println("Porcentaje: " + salaVO.getPorcentaje() + "%");
        System.out.println("Ingresos: " + salaVO.getIngresos() + "€");
    }
}