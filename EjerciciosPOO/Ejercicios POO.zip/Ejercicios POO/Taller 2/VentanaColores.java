import javax.swing.*;

public class VentanaColores extends JFrame {

    private JPanel panelColores;
    private JRadioButton optRojo;
    private JRadioButton optVerde;
    private JRadioButton optAzul;
    private ButtonGroup grupoColores;
    private JButton btnAceptar;
    private JLabel etiResultado;

    public VentanaColores() {
        initComponents();
        optRojo.setSelected(true); // Activar "Rojo" por defecto
    }

    private void initComponents() {
        // Inicializar componentes
        panelColores = new JPanel();
        optRojo = new JRadioButton("Rojo");
        optVerde = new JRadioButton("Verde");
        optAzul = new JRadioButton("Azul");
        grupoColores = new ButtonGroup();
        btnAceptar = new JButton("Aceptar");
        etiResultado = new JLabel(" ");

        // Agrupar los RadioButtons
        grupoColores.add(optRojo);
        grupoColores.add(optVerde);
        grupoColores.add(optAzul);

        // Configurar el panel con título
        panelColores.setBorder(BorderFactory.createTitledBorder("Colores"));
        panelColores.setLayout(new BoxLayout(panelColores, BoxLayout.Y_AXIS));
        panelColores.add(optRojo);
        panelColores.add(optVerde);
        panelColores.add(optAzul);

        // Añadir evento al botón
        btnAceptar.addActionListener(e -> mostrarColor());

        // Configurar la ventana
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Botones de Opción");
        setLayout(null); // Usamos posicionamiento absoluto

        // Posicionar los componentes
        panelColores.setBounds(20, 20, 150, 120);
        btnAceptar.setBounds(200, 30, 100, 30);
        etiResultado.setBounds(200, 80, 200, 30);

        // Añadir componentes al JFrame
        add(panelColores);
        add(btnAceptar);
        add(etiResultado);

        // Tamaño de la ventana
        setSize(450, 200);
        setLocationRelativeTo(null); // Centrar la ventana
        setVisible(true);
    }

    private void mostrarColor() {
        String mensaje = "Color elegido: ";

        if (optRojo.isSelected()) {
            mensaje += "Rojo";
        } else if (optVerde.isSelected()) {
            mensaje += "Verde";
        } else if (optAzul.isSelected()) {
            mensaje += "Azul";
        }

        etiResultado.setText(mensaje);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new VentanaColores());
    }
}
