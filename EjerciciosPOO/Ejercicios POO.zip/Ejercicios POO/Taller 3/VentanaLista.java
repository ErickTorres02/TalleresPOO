import javax.swing.*;

public class VentanaLista extends JFrame {

    private JScrollPane scrollPane;
    private JList<String> lstColores;
    private JButton btnAceptar;
    private JLabel etiResultado;

    public VentanaLista() {
        initComponents();
    }

    private void initComponents() {
        // Crear componentes
        String[] colores = {"Rojo", "Verde", "Azul"};
        lstColores = new JList<>(colores);
        scrollPane = new JScrollPane(lstColores);
        btnAceptar = new JButton("Aceptar");
        etiResultado = new JLabel(" ");

        // Acción del botón Aceptar
        btnAceptar.addActionListener(e -> mostrarColorSeleccionado());

        // Configurar la ventana
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Lista de Colores");
        setLayout(null);

        // Posicionar componentes
        scrollPane.setBounds(20, 20, 100, 80);
        btnAceptar.setBounds(140, 20, 100, 30);
        etiResultado.setBounds(140, 60, 250, 30);
        etiResultado.setBorder(BorderFactory.createEtchedBorder());

        // Agregar componentes
        add(scrollPane);
        add(btnAceptar);
        add(etiResultado);

        // Tamaño de la ventana
        setSize(400, 180);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void mostrarColorSeleccionado() {
        String mensaje;

        if (lstColores.getSelectedIndex() == -1) {
            mensaje = "No hay un color seleccionado.";
        } else {
            mensaje = "El color seleccionado es: " + lstColores.getSelectedValue().toString();
        }

        etiResultado.setText(mensaje);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new VentanaLista());
    }
}
