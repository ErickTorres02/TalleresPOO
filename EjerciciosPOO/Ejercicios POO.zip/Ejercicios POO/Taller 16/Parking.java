import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Parking extends JFrame {
    private int coches;
    private JButton btnEntro, btnSalio, btnReiniciar;
    private JLabel etiCoches;

    public Parking() {
        coches = 0;
        
        setTitle("Control de Parking");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());
        
        btnEntro = new JButton("Entró un coche");
        btnSalio = new JButton("Salió un coche");
        btnReiniciar = new JButton("Reiniciar");
        
        add(new JLabel("Coches en el Parking:"));
        etiCoches = new JLabel("0");
        etiCoches.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        etiCoches.setPreferredSize(new Dimension(50, 20));
        add(etiCoches);
        
        add(btnEntro);
        add(btnSalio);
        add(btnReiniciar);
        
        btnEntro.addActionListener(e -> {
            coches++;
            etiCoches.setText(String.valueOf(coches));
        });
        
        btnSalio.addActionListener(e -> {
            if (coches > 0) {
                coches--;
                etiCoches.setText(String.valueOf(coches));
            }
        });
        
        btnReiniciar.addActionListener(e -> {
            coches = 0;
            etiCoches.setText("0");
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Parking parking = new Parking();
            parking.setVisible(true);
        });
    }
}