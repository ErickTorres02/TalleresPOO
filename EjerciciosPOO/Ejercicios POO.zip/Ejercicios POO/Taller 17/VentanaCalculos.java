import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class VentanaCalculos extends JFrame {
    private JTextField txtNumero1, txtNumero2;
    private JLabel etiResultado;
    
    public VentanaCalculos() {
        setTitle("Calculadora");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(5, 2, 10, 10));
        
       
        JMenuBar menuBarra = new JMenuBar();
        JMenu menuCalcular = new JMenu("Calcular");
        
        JMenuItem menuSumar = new JMenuItem("Sumar");
        JMenuItem menuRestar = new JMenuItem("Restar");
        JMenuItem menuBorrar = new JMenuItem("Borrar");
        
        menuCalcular.add(menuSumar);
        menuCalcular.add(menuRestar);
        menuCalcular.add(menuBorrar);
        menuBarra.add(menuCalcular);
        setJMenuBar(menuBarra);
        
        
        add(new JLabel("Número 1:"));
        txtNumero1 = new JTextField("0");
        add(txtNumero1);
        
        add(new JLabel("Número 2:"));
        txtNumero2 = new JTextField("0");
        add(txtNumero2);
        
        add(new JLabel("Resultado:"));
        etiResultado = new JLabel();
        add(etiResultado);
        
        JButton btnSumar = new JButton("Sumar");
        JButton btnRestar = new JButton("Restar");
        JButton btnBorrar = new JButton("Borrar");
        
        add(btnSumar);
        add(btnRestar);
        add(btnBorrar);
        
        
        ActionListener sumarListener = e -> Sumar();
        ActionListener restarListener = e -> Restar();
        ActionListener borrarListener = e -> Borrar();
        
        btnSumar.addActionListener(sumarListener);
        menuSumar.addActionListener(sumarListener);
        txtNumero1.addActionListener(sumarListener);
        txtNumero2.addActionListener(sumarListener);
        
        btnRestar.addActionListener(restarListener);
        menuRestar.addActionListener(restarListener);
        
        btnBorrar.addActionListener(borrarListener);
        menuBorrar.addActionListener(borrarListener);
    }
    
    private void Sumar() {
        try {
            int a = Integer.parseInt(txtNumero1.getText());
            int b = Integer.parseInt(txtNumero2.getText());
            etiResultado.setText(String.valueOf(a + b));
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Ingrese números válidos");
        }
    }
    
    private void Restar() {
        try {
            int a = Integer.parseInt(txtNumero1.getText());
            int b = Integer.parseInt(txtNumero2.getText());
            etiResultado.setText(String.valueOf(a - b));
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Ingrese números válidos");
        }
    }
    
    private void Borrar() {
        txtNumero1.setText("0");
        txtNumero2.setText("0");
        etiResultado.setText("");
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            VentanaCalculos ventana = new VentanaCalculos();
            ventana.setVisible(true);
        });
    }
}