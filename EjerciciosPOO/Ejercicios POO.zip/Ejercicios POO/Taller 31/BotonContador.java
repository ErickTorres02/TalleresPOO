package paqueteprincipal;

import javax.swing.JButton;

public class BotonContador extends JButton {
    private int pulsaciones;

    public BotonContador() {
        pulsaciones = 0;
    }

    public void setPulsaciones(int p) {
        pulsaciones = p;
    }

    public int getPulsaciones() {
        return pulsaciones;
    }

    public void incrementa() {
        pulsaciones++;
    }

    public void decrementa() {
        if (pulsaciones > 0) {
            pulsaciones--;
        }
    }

    public void reiniciar() {
        pulsaciones = 0;
    }

    public void aumentar(int c) {
        pulsaciones += c;
    }

    public void disminuir(int c) {
        pulsaciones = Math.max(0, pulsaciones - c);
    }
}