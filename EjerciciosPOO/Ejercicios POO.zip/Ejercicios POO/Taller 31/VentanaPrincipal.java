import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class VentanaPrincipal extends JFrame {
    private BotonContador btnA;
    private BotonContador btnB;
    private BotonContador btnC;
    private JButton btnVerPulsaciones;
    private JButton btnReiniciar;
    private JButton btnIniciar;
    private JTextField txtNumero;

    public VentanaPrincipal() {
        setTitle("Botones Contadores");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());
        
        initComponents();
        configurarEventos();
    }

    private void initComponents() {
        btnA = new BotonContador();
        btnA.setText("Botón A");
        add(btnA);

        btnB = new BotonContador();
        btnB.setText("Botón B");
        add(btnB);

        btnC = new BotonContador();
        btnC.setText("Botón C");
        add(btnC);

        btnVerPulsaciones = new JButton("Ver Pulsaciones");
        add(btnVerPulsaciones);

        btnReiniciar = new JButton("Reiniciar");
        add(btnReiniciar);

        txtNumero = new JTextField(5);
        add(new JLabel("Valor inicial:"));
        add(txtNumero);

        btnIniciar = new JButton("Iniciar");
        add(btnIniciar);
    }

    private void configurarEventos() {
        btnA.addActionListener(e -> {
            btnA.incrementa();
        });

        btnB.addActionListener(e -> {
            btnB.incrementa();
        });

        btnC.addActionListener(e -> {
            btnC.aumentar(2);
        });

        btnVerPulsaciones.addActionListener(e -> {
            String mensaje = "Pulsaciones:\n" +
                            "Botón A: " + btnA.getPulsaciones() + "\n" +
                            "Botón B: " + btnB.getPulsaciones() + "\n" +
                            "Botón C: " + btnC.getPulsaciones();
            JOptionPane.showMessageDialog(this, mensaje);
        });

        btnReiniciar.addActionListener(e -> {
            btnA.reiniciar();
            btnB.reiniciar();
            btnC.reiniciar();
            JOptionPane.showMessageDialog(this, "Contadores reiniciados");
        });

        btnIniciar.addActionListener(e -> {
            try {
                int valor = Integer.parseInt(txtNumero.getText());
                btnA.setPulsaciones(valor);
                btnB.setPulsaciones(valor);
                btnC.setPulsaciones(valor);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Ingrese un número válido");
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            VentanaPrincipal ventana = new VentanaPrincipal();
            ventana.setVisible(true);
        });
    }
}