import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class EventosRaton extends JFrame {
   
    private JLabel etiZona;
    private JLabel etiResultado;

    public EventosRaton() {
        
        setTitle("Eventos de Ratón");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());
        
        
        CreacionVentana();
    }

    private void CreacionVentana() {
        
        getContentPane().setBackground(Color.WHITE);
        
        
        etiZona = new JLabel();
        etiZona.setOpaque(true);
        etiZona.setBackground(Color.RED);
        etiZona.setPreferredSize(new Dimension(200, 150));
        etiZona.setText("Zona interactiva");
        etiZona.setHorizontalAlignment(SwingConstants.CENTER);
        add(etiZona);
        
        
        etiResultado = new JLabel();
        etiResultado.setOpaque(true);
        etiResultado.setBackground(Color.WHITE);
        etiResultado.setPreferredSize(new Dimension(200, 50));
        etiResultado.setText("Esperando interacción...");
        etiResultado.setHorizontalAlignment(SwingConstants.CENTER);
        add(etiResultado);
        

        configurarEventosRaton();
    }
    
    private void configurarEventosRaton() {
        
        etiZona.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                etiZonaMouseEntered(evt);
            }
            
            public void mouseExited(MouseEvent evt) {
                etiZonaMouseExited(evt);
            }
            
            public void mousePressed(MouseEvent evt) {
                etiZonaMousePressed(evt);
            }
        });
    }
    
    
    private void etiZonaMouseEntered(MouseEvent evt) {
        etiResultado.setText("Ratón entró en la zona roja");
    }
    
    private void etiZonaMouseExited(MouseEvent evt) {
        etiResultado.setText("Ratón salió de la zona roja");
    }
    
    private void etiZonaMousePressed(MouseEvent evt) {
        String boton = "";
        switch(evt.getButton()) {
            case MouseEvent.BUTTON1:
                boton = "izquierdo";
                break;
            case MouseEvent.BUTTON2:
                boton = "central";
                break;
            case MouseEvent.BUTTON3:
                boton = "derecho";
                break;
        }
        etiResultado.setText("Se pulsó el botón " + boton);
    }
    
    public static void main(String[] args) {
        EventosRaton ventana = new EventosRaton();
        ventana.setVisible(true);
    }
}