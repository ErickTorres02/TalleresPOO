import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class EjercicioToggleButtons extends JFrame implements ActionListener {
    private JTextField txtPrecioBase;
    private JButton btnCalcular;
    private JLabel etiTotal;
    private JToggleButton tbtnInstalacion, tbtnFormacion, tbtnAlimentacionBD;
    private JLabel etiPrecioInstalacion, etiPrecioFormacion, etiPrecioAlimentacionBD;

    public EjercicioToggleButtons() {
        // Configuración básica de la ventana
        setTitle("Calculadora de Precios con ToggleButtons");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(0, 2, 10, 10));
        getContentPane().setBackground(new Color(240, 240, 240));

        // Creación de los componentes
        add(new JLabel("Precio Base:"));
        txtPrecioBase = new JTextField();
        add(txtPrecioBase);

        // ToggleButtons
        tbtnInstalacion = new JToggleButton("Instalación");
        tbtnFormacion = new JToggleButton("Formación");
        tbtnAlimentacionBD = new JToggleButton("Alimentación BD");
        
        // Establecer Instalación como seleccionada por defecto
        tbtnInstalacion.setSelected(true);

        // Etiquetas de precios
        etiPrecioInstalacion = new JLabel("40");
        etiPrecioFormacion = new JLabel("200");
        etiPrecioAlimentacionBD = new JLabel("200");

        // Botón calcular
        btnCalcular = new JButton("Calcular");
        btnCalcular.setBackground(new Color(100, 150, 255));
        btnCalcular.setForeground(Color.WHITE);

        // Etiqueta de total
        etiTotal = new JLabel("");
        etiTotal.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        etiTotal.setFont(new Font("Arial", Font.BOLD, 16));
        etiTotal.setHorizontalAlignment(SwingConstants.CENTER);

        // Añadir componentes a la ventana
        add(tbtnInstalacion);
        add(etiPrecioInstalacion);
        add(tbtnFormacion);
        add(etiPrecioFormacion);
        add(tbtnAlimentacionBD);
        add(etiPrecioAlimentacionBD);
        add(btnCalcular);
        add(etiTotal);

        // Asignar listeners
        btnCalcular.addActionListener(this);

        // Añadir padding alrededor de los componentes
        ((JComponent) getContentPane()).setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnCalcular) {
            try {
                double precio_base = Double.parseDouble(txtPrecioBase.getText());
                double precio_instal = Double.parseDouble(etiPrecioInstalacion.getText());
                double precio_for = Double.parseDouble(etiPrecioFormacion.getText());
                double precio_ali = Double.parseDouble(etiPrecioAlimentacionBD.getText());

                double precio_total = precio_base;

                if (tbtnInstalacion.isSelected()) {
                    precio_total += precio_instal;
                }
                if (tbtnFormacion.isSelected()) {
                    precio_total += precio_for;
                }
                if (tbtnAlimentacionBD.isSelected()) {
                    precio_total += precio_ali;
                }

                etiTotal.setText(String.format("%.2f €", precio_total));
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Por favor, introduce un precio base válido", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            EjercicioToggleButtons ventana = new EjercicioToggleButtons();
            ventana.setVisible(true);
        });
    }
}