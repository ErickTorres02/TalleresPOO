import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class EventosRatonCompleto extends JFrame {
    private JLabel etiTexto;
    private JTextArea areaInformacion;

    public EventosRatonCompleto() {
        setTitle("Eventos de Ratón Completo");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        
        initComponents();
        configurarEventosRaton();
    }

    private void initComponents() {
       
        etiTexto = new JLabel("Pase el ratón o haga clic aquí", SwingConstants.CENTER);
        etiTexto.setOpaque(true);
        etiTexto.setBackground(new Color(255, 200, 200));
        etiTexto.setPreferredSize(new Dimension(0, 150));
        etiTexto.setFont(new Font("Arial", Font.BOLD, 16));
        
       
        areaInformacion = new JTextArea();
        areaInformacion.setEditable(false);
        areaInformacion.setFont(new Font("Monospaced", Font.PLAIN, 12));
        
        add(etiTexto, BorderLayout.NORTH);
        add(new JScrollPane(areaInformacion), BorderLayout.CENTER);
    }

    private void configurarEventosRaton() {
        etiTexto.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                etiTextoMouseEntered(evt);
            }
            
            public void mouseExited(MouseEvent evt) {
                etiTextoMouseExited(evt);
            }
            
            public void mousePressed(MouseEvent evt) {
                etiTextoMousePressed(evt);
            }
            
            public void mouseReleased(MouseEvent evt) {
                etiTextoMouseReleased(evt);
            }
            
            public void mouseClicked(MouseEvent evt) {
                etiTextoMouseClicked(evt);
            }
        });
    }

    
    private void etiTextoMouseEntered(MouseEvent evt) {
        etiTexto.setBackground(new Color(200, 255, 200));
        logEvento("Ratón ENTRÓ en la etiqueta");
    }

    private void etiTextoMouseExited(MouseEvent evt) {
        etiTexto.setBackground(new Color(255, 200, 200));
        logEvento("Ratón SALIÓ de la etiqueta");
    }

    private void etiTextoMousePressed(MouseEvent evt) {
        logEvento("Botón PRESIONADO en (" + evt.getX() + ", " + evt.getY() + ")");
    }

    private void etiTextoMouseReleased(MouseEvent evt) {
        logEvento("Botón LIBERADO en (" + evt.getX() + ", " + evt.getY() + ")");
    }

    private void etiTextoMouseClicked(MouseEvent evt) {
        String boton = "";
        switch(evt.getButton()) {
            case MouseEvent.BUTTON1: boton = "izquierdo"; break;
            case MouseEvent.BUTTON2: boton = "central"; break;
            case MouseEvent.BUTTON3: boton = "derecho"; break;
        }
        
        String clics = evt.getClickCount() > 1 ? " (" + evt.getClickCount() + " clics)" : "";
        logEvento("CLIC con botón " + boton + clics + " en (" + evt.getX() + ", " + evt.getY() + ")");
    }

    private void logEvento(String mensaje) {
        areaInformacion.append(mensaje + "\n");
        areaInformacion.setCaretPosition(areaInformacion.getDocument().getLength());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            EventosRatonCompleto ventana = new EventosRatonCompleto();
            ventana.setVisible(true);
        });
    }
}