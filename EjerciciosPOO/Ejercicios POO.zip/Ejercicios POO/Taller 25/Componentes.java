import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Componentes extends JFrame {
   
    private JCheckBox[] vcuadros;  
    private JButton btnAceptar;    
    private JLabel etiResultado;   

   
    public Componentes() {
        setTitle("Vector de Componentes JCheckBox");
        setSize(350, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);  
        
        CreacionVentana();  
    }

    private void CreacionVentana() {
       
        getContentPane().setBackground(Color.WHITE);
        
        
        vcuadros = new JCheckBox[10];
        
       
        String[] colores = {"Rojo", "Azul", "Verde", "Amarillo", "Naranja", 
                           "Morado", "Rosa", "Marrón", "Gris", "Negro"};
        
        
        for (int i = 0; i < vcuadros.length; i++) {
            vcuadros[i] = new JCheckBox(colores[i]);  // Inicializar con texto
            vcuadros[i].setBounds(10, 10 + 30 * i, 150, 20);  // Posición (x, y, ancho, alto)
            vcuadros[i].setBackground(Color.WHITE);
            add(vcuadros[i]);  
        }
        
        
        btnAceptar = new JButton("Aceptar");
        btnAceptar.setBounds(180, 10, 120, 30);
        btnAceptar.addActionListener(e -> btnAceptarActionPerformed(e));
        add(btnAceptar);
        
        
        etiResultado = new JLabel("Selecciona opciones y pulsa Aceptar");
        etiResultado.setBounds(10, 320, 320, 50);
        etiResultado.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        etiResultado.setVerticalAlignment(SwingConstants.TOP);
        add(etiResultado);
    }

    
    private void btnAceptarActionPerformed(ActionEvent evt) {
        int contador = 0;
        StringBuilder seleccionados = new StringBuilder("Opciones seleccionadas:\n");
        
        
        for (JCheckBox cuadro : vcuadros) {
            if (cuadro.isSelected()) {
                contador++;
                seleccionados.append("- ").append(cuadro.getText()).append("\n");
            }
        }
       
        etiResultado.setText("<html>Total seleccionados: " + contador + "<br>" + seleccionados.toString() + "</html>");
    }

    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Componentes ventana = new Componentes();
            ventana.setVisible(true);
        });
    }
}