import java.awt.*;
import javax.swing.*;

public class LayoutExamples {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            
            JFrame freeDesignFrame = new JFrame("Diseño Libre");
            freeDesignFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            freeDesignFrame.setSize(400, 300);
            freeDesignFrame.setLayout(null);
            
            JLabel label1 = new JLabel("Etiqueta");
            label1.setBounds(50, 50, 100, 30);
            freeDesignFrame.add(label1);
            
            JButton button1 = new JButton("Botón");
            button1.setBounds(200, 100, 100, 30);
            freeDesignFrame.add(button1);
            
           
            JFrame absoluteFrame = new JFrame("AbsoluteLayout");
            absoluteFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            absoluteFrame.setSize(400, 300);
            absoluteFrame.setLayout(null);
            
            JLabel label2 = new JLabel("Etiqueta");
            label2.setBounds(100, 50, 100, 30);
            absoluteFrame.add(label2);
            
            JButton button2 = new JButton("Botón");
            button2.setBounds(250, 150, 100, 30);
            absoluteFrame.add(button2);
           
            JFrame flowFrame = new JFrame("FlowLayout");
            flowFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            flowFrame.setSize(400, 300);
            flowFrame.setLayout(new FlowLayout());
            
            flowFrame.add(new JLabel("Etiqueta 1"));
            flowFrame.add(new JButton("Botón 1"));
            flowFrame.add(new JLabel("Etiqueta 2"));
            flowFrame.add(new JButton("Botón 2"));
            
            
            JFrame gridFrame = new JFrame("GridLayout");
            gridFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            gridFrame.setSize(400, 300);
            gridFrame.setLayout(new GridLayout(2, 3));
            
            gridFrame.add(new JButton("Botón 1"));
            gridFrame.add(new JButton("Botón 2"));
            gridFrame.add(new JButton("Botón 3"));
            gridFrame.add(new JButton("Botón 4"));
            gridFrame.add(new JButton("Botón 5"));
            gridFrame.add(new JButton("Botón 6"));
            
           
            JFrame borderFrame = new JFrame("BorderLayout");
            borderFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            borderFrame.setSize(400, 300);
            borderFrame.setLayout(new BorderLayout());
            
            borderFrame.add(new JButton("Norte"), BorderLayout.NORTH);
            borderFrame.add(new JButton("Sur"), BorderLayout.SOUTH);
            borderFrame.add(new JButton("Este"), BorderLayout.EAST);
            borderFrame.add(new JButton("Oeste"), BorderLayout.WEST);
            borderFrame.add(new JButton("Centro"), BorderLayout.CENTER);
            
            freeDesignFrame.setVisible(true);
            absoluteFrame.setVisible(true);
            flowFrame.setVisible(true);
            gridFrame.setVisible(true);
            borderFrame.setVisible(true);
        });
    }
}