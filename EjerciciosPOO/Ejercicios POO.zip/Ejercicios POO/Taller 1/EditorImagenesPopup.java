import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.util.Random;
import javax.swing.*;

public class EditorImagenesPopup {
    private JFrame frame;
    private JPanel panelImagen;
    private BufferedImage imagen;
    private JPopupMenu menuContextual;

    public EditorImagenesPopup() {
        frame = new JFrame("Editor de Imágenes con Menú Contextual");
        frame.setLayout(new BorderLayout());
        
        // Crear una imagen de ejemplo
        imagen = new BufferedImage(600, 400, BufferedImage.TYPE_INT_RGB);
        dibujarImagenInicial();
        
        // Panel para mostrar la imagen
        panelImagen = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(imagen, 0, 0, this);
            }
        };
        panelImagen.setPreferredSize(new Dimension(600, 400));
        
        // Configurar menú contextual
        crearMenuContextual();
        
        // Añadir listeners para el menú contextual
        panelImagen.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                if (e.isPopupTrigger()) {
                    mostrarMenu(e);
                }
            }
            
            public void mouseReleased(MouseEvent e) {
                if (e.isPopupTrigger()) {
                    mostrarMenu(e);
                }
            }
        });
        
        frame.add(panelImagen, BorderLayout.CENTER);
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
    
    private void dibujarImagenInicial() {
        Graphics2D g2d = imagen.createGraphics();
        g2d.setColor(Color.WHITE);
        g2d.fillRect(0, 0, imagen.getWidth(), imagen.getHeight());
        g2d.setColor(Color.BLUE);
        g2d.drawString("Haz clic derecho para mostrar el menú contextual", 50, 50);
        g2d.dispose();
    }
    
    private void crearMenuContextual() {
        menuContextual = new JPopupMenu();
        
        // Submenú para filtros
        JMenu menuFiltros = new JMenu("Aplicar Filtro");
        JMenuItem itemEscalaGrises = new JMenuItem("Escala de grises");
        JMenuItem itemNegativo = new JMenuItem("Negativo");
        JMenuItem itemSepia = new JMenuItem("Sepia");
        
        menuFiltros.add(itemEscalaGrises);
        menuFiltros.add(itemNegativo);
        menuFiltros.add(itemSepia);
        
        // Otros items del menú
        JMenuItem itemRotar = new JMenuItem("Rotar 90°");
        JMenuItem itemAleatorio = new JMenuItem("Efecto Aleatorio");
        JMenuItem itemRestaurar = new JMenuItem("Restaurar Imagen Original");
        
        menuContextual.add(menuFiltros);
        menuContextual.addSeparator();
        menuContextual.add(itemRotar);
        menuContextual.add(itemAleatorio);
        menuContextual.addSeparator();
        menuContextual.add(itemRestaurar);
        
        // Configurar acciones
        itemEscalaGrises.addActionListener(e -> aplicarFiltroEscalaGrises());
        itemNegativo.addActionListener(e -> aplicarFiltroNegativo());
        itemSepia.addActionListener(e -> aplicarFiltroSepia());
        itemRotar.addActionListener(e -> rotarImagen());
        itemAleatorio.addActionListener(e -> aplicarEfectoAleatorio());
        itemRestaurar.addActionListener(e -> restaurarImagen());
    }
    
    private void mostrarMenu(MouseEvent e) {
        menuContextual.show(e.getComponent(), e.getX(), e.getY());
    }
    
    private void aplicarFiltroEscalaGrises() {
        for (int y = 0; y < imagen.getHeight(); y++) {
            for (int x = 0; x < imagen.getWidth(); x++) {
                Color color = new Color(imagen.getRGB(x, y));
                int gris = (int)(color.getRed() * 0.299 + color.getGreen() * 0.587 + color.getBlue() * 0.114);
                imagen.setRGB(x, y, new Color(gris, gris, gris).getRGB());
            }
        }
        panelImagen.repaint();
    }
    
    private void aplicarFiltroNegativo() {
        for (int y = 0; y < imagen.getHeight(); y++) {
            for (int x = 0; x < imagen.getWidth(); x++) {
                Color color = new Color(imagen.getRGB(x, y));
                imagen.setRGB(x, y, new Color(
                    255 - color.getRed(),
                    255 - color.getGreen(),
                    255 - color.getBlue()).getRGB());
            }
        }
        panelImagen.repaint();
    }
    
    private void aplicarFiltroSepia() {
        for (int y = 0; y < imagen.getHeight(); y++) {
            for (int x = 0; x < imagen.getWidth(); x++) {
                Color color = new Color(imagen.getRGB(x, y));
                int r = color.getRed();
                int g = color.getGreen();
                int b = color.getBlue();
                
                int tr = (int)(0.393 * r + 0.769 * g + 0.189 * b);
                int tg = (int)(0.349 * r + 0.686 * g + 0.168 * b);
                int tb = (int)(0.272 * r + 0.534 * g + 0.131 * b);
                
                tr = Math.min(255, tr);
                tg = Math.min(255, tg);
                tb = Math.min(255, tb);
                
                imagen.setRGB(x, y, new Color(tr, tg, tb).getRGB());
            }
        }
        panelImagen.repaint();
    }
    
    private void rotarImagen() {
        BufferedImage nuevaImagen = new BufferedImage(imagen.getHeight(), imagen.getWidth(), imagen.getType());
        
        for (int y = 0; y < imagen.getHeight(); y++) {
            for (int x = 0; x < imagen.getWidth(); x++) {
                nuevaImagen.setRGB(y, imagen.getWidth() - 1 - x, imagen.getRGB(x, y));
            }
        }
        
        imagen = nuevaImagen;
        panelImagen.setPreferredSize(new Dimension(imagen.getWidth(), imagen.getHeight()));
        frame.pack();
        panelImagen.repaint();
    }
    
    private void aplicarEfectoAleatorio() {
        Random rand = new Random();
        for (int y = 0; y < imagen.getHeight(); y++) {
            for (int x = 0; x < imagen.getWidth(); x++) {
                Color color = new Color(imagen.getRGB(x, y));
                int r = color.getRed() + rand.nextInt(50) - 25;
                int g = color.getGreen() + rand.nextInt(50) - 25;
                int b = color.getBlue() + rand.nextInt(50) - 25;
                
                r = Math.max(0, Math.min(255, r));
                g = Math.max(0, Math.min(255, g));
                b = Math.max(0, Math.min(255, b));
                
                imagen.setRGB(x, y, new Color(r, g, b).getRGB());
            }
        }
        panelImagen.repaint();
    }
    
    private void restaurarImagen() {
        dibujarImagenInicial();
        panelImagen.repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new EditorImagenesPopup());
    }
}