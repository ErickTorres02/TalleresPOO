import java.awt.event.*;
import javax.swing.*;

public class ListaColores {
    private final JFrame frame;
    private JList<String> lstColores;
    private final JButton btnAceptar;
    private JLabel etiResultado;

    public ListaColores() {
        frame = new JFrame("Lista de Colores");
        frame.setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.Y_AXIS));
        
        String[] colores = {"Rojo", "Verde", "Azul"};
        lstColores = new JList<>(colores);
        lstColores.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        JScrollPane scrollPane = new JScrollPane(lstColores);
        
        btnAceptar = new JButton("Aceptar");
        etiResultado = new JLabel("El color seleccionado es: ");
        etiResultado.setBorder(BorderFactory.createEtchedBorder());
        
        btnAceptar.addActionListener((ActionEvent e) -> {
            if (lstColores.getSelectedIndex() == -1) {
                etiResultado.setText("No hay un color seleccionado.");
            } else {
                etiResultado.setText("El color seleccionado es: " +
                        lstColores.getSelectedValue());
            }
        });
        
        frame.add(scrollPane);
        frame.add(btnAceptar);
        frame.add(etiResultado);
        
        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new ListaColores();
    }
}
