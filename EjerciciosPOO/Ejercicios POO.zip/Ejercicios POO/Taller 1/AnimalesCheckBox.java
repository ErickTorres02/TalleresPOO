import javax.swing.*;
import java.awt.event.*;

public class AnimalesCheckBox {
    private JFrame frame;
    private JCheckBox chkPerro, chkGato, chkRaton;
    private JButton btnAceptar;
    private JLabel etiResultado;

    public AnimalesCheckBox() {
        frame = new JFrame("Selección de Animales");
        frame.setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.Y_AXIS));
        
        chkPerro = new JCheckBox("Perro");
        chkGato = new JCheckBox("Gato");
        chkRaton = new JCheckBox("Ratón");
        
        btnAceptar = new JButton("Aceptar");
        etiResultado = new JLabel("Animales elegidos: ");
        etiResultado.setBorder(BorderFactory.createEtchedBorder());
        
        btnAceptar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String mensaje = "Animales elegidos: ";
                if (chkPerro.isSelected()) mensaje += "Perro ";
                if (chkGato.isSelected()) mensaje += "Gato ";
                if (chkRaton.isSelected()) mensaje += "Ratón ";
                etiResultado.setText(mensaje);
            }
        });
        
        frame.add(chkPerro);
        frame.add(chkGato);
        frame.add(chkRaton);
        frame.add(btnAceptar);
        frame.add(etiResultado);
        
        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new AnimalesCheckBox();
    }
}