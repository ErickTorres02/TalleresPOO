import java.awt.event.*;
import javax.swing.*;

public class ComboColores {
    private final JFrame frame;
    private JComboBox<String> cboColores;
    private JLabel etiResultado;

    public ComboColores() {
        frame = new JFrame("Combo de Colores");
        frame.setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.Y_AXIS));
        
        String[] colores = {"Rojo", "Verde", "Azul"};
        cboColores = new JComboBox<>(colores);
        cboColores.setEditable(true);
        
        etiResultado = new JLabel("El color elegido es: ");
        etiResultado.setBorder(BorderFactory.createEtchedBorder());
        
        cboColores.addActionListener((ActionEvent e) -> {
            etiResultado.setText("El color elegido es: " +
                    cboColores.getSelectedItem().toString());
        });
        
        frame.add(cboColores);
        frame.add(etiResultado);
        
        frame.setSize(300, 150);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new ComboColores();
    }
}
