import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;

public class ControlDeslizante {
    private JFrame ventana;
    private JSlider deslizador;
    private JLabel etiquetaValor;
    private JPanel panelColor;

    public ControlDeslizante() {
        // Configurar la ventana principal
        ventana = new JFrame("Control Deslizante de Color");
        ventana.setLayout(new BorderLayout(10, 10));
        
        // Crear el control deslizante (JSlider)
        deslizador = new JSlider(JSlider.HORIZONTAL, 0, 255, 128);
        configurarDeslizador();
        
        // Panel para mostrar el color
        panelColor = new JPanel();
        panelColor.setPreferredSize(new Dimension(200, 200));
        actualizarColor(128);
        
        // Etiqueta para mostrar el valor
        etiquetaValor = new JLabel("Valor RGB: 128", JLabel.CENTER);
        etiquetaValor.setBorder(BorderFactory.createEtchedBorder());
        etiquetaValor.setFont(new Font("Arial", Font.BOLD, 16));
        
        // Añadir componentes a la ventana
        ventana.add(deslizador, BorderLayout.NORTH);
        ventana.add(panelColor, BorderLayout.CENTER);
        ventana.add(etiquetaValor, BorderLayout.SOUTH);
        
        // Configurar ventana
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.setSize(400, 350);
        ventana.setLocationRelativeTo(null);
        ventana.setVisible(true);
    }
    
    private void configurarDeslizador() {
        // Configuración visual del deslizador
        deslizador.setMajorTickSpacing(50);
        deslizador.setMinorTickSpacing(10);
        deslizador.setPaintTicks(true);
        deslizador.setPaintLabels(true);
        deslizador.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Escucha de cambios en el deslizador
        deslizador.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                int valor = deslizador.getValue();
                etiquetaValor.setText("Valor RGB: " + valor);
                actualizarColor(valor);
            }
        });
    }
    
    private void actualizarColor(int valor) {
        // Crear un color basado en el valor del deslizador
        Color color = new Color(valor, valor, valor);
        panelColor.setBackground(color);
        
        // Cambiar el color del texto según el fondo para mejor contraste
        if (valor > 128) {
            panelColor.setForeground(Color.BLACK);
        } else {
            panelColor.setForeground(Color.WHITE);
        }
    }

    public static void main(String[] args) {
        // Ejecutar en el hilo de eventos de Swing
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new ControlDeslizante();
            }
        });
    }
}