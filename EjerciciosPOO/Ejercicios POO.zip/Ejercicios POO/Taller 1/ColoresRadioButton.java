import javax.swing.*;
import java.awt.event.*;

public class ColoresRadioButton {
    private JFrame frame;
    private JRadioButton optRojo, optVerde, optAzul;
    private ButtonGroup grupoColores;
    private JButton btnAceptar;
    private JLabel etiResultado;

    public ColoresRadioButton() {
        frame = new JFrame("Selección de Colores");
        frame.setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.Y_AXIS));
        
        JPanel panel = new JPanel();
        panel.setBorder(BorderFactory.createTitledBorder("Colores"));
        
        optRojo = new JRadioButton("Rojo", true);
        optVerde = new JRadioButton("Verde");
        optAzul = new JRadioButton("Azul");
        
        grupoColores = new ButtonGroup();
        grupoColores.add(optRojo);
        grupoColores.add(optVerde);
        grupoColores.add(optAzul);
        
        btnAceptar = new JButton("Aceptar");
        etiResultado = new JLabel("Color elegido: ");
        etiResultado.setBorder(BorderFactory.createEtchedBorder());
        
        btnAceptar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String mensaje = "Color elegido: ";
                if (optRojo.isSelected()) mensaje += "Rojo";
                else if (optVerde.isSelected()) mensaje += "Verde";
                else if (optAzul.isSelected()) mensaje += "Azul";
                etiResultado.setText(mensaje);
            }
        });
        
        panel.add(optRojo);
        panel.add(optVerde);
        panel.add(optAzul);
        
        frame.add(panel);
        frame.add(btnAceptar);
        frame.add(etiResultado);
        
        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new ColoresRadioButton();
    }
}