import java.awt.*;
import java.io.*;
import javax.swing.*;

public class EditorTextoConMenu {
    private JFrame frame;
    private JTextArea areaTexto;
    private JFileChooser fileChooser;
    private File archivoActual;

    public EditorTextoConMenu() {
        frame = new JFrame("Editor de Texto Avanzado");
        frame.setLayout(new BorderLayout());
        
        
        areaTexto = new JTextArea();
        areaTexto.setFont(new Font("Monospaced", Font.PLAIN, 14));
        JScrollPane scrollPane = new JScrollPane(areaTexto);
        
        
        JToolBar toolBar = crearBarraHerramientas();
        
       
        JMenuBar menuBar = crearBarraMenu();
       
        frame.setJMenuBar(menuBar);
        frame.add(toolBar, BorderLayout.NORTH);
        frame.add(scrollPane, BorderLayout.CENTER);
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        
        fileChooser = new JFileChooser();
    }
    
    private JMenuBar crearBarraMenu() {
        JMenuBar menuBar = new JMenuBar();
        
       
        JMenu menuArchivo = new JMenu("Archivo");
        JMenuItem itemNuevo = new JMenuItem("Nuevo");
        JMenuItem itemAbrir = new JMenuItem("Abrir...");
        JMenuItem itemGuardar = new JMenuItem("Guardar");
        JMenuItem itemGuardarComo = new JMenuItem("Guardar como...");
        JMenuItem itemSalir = new JMenuItem("Salir");
        
        menuArchivo.add(itemNuevo);
        menuArchivo.add(itemAbrir);
        menuArchivo.addSeparator();
        menuArchivo.add(itemGuardar);
        menuArchivo.add(itemGuardarComo);
        menuArchivo.addSeparator();
        menuArchivo.add(itemSalir);
        
       
        JMenu menuEdicion = new JMenu("Edición");
        JMenuItem itemCortar = new JMenuItem("Cortar");
        JMenuItem itemCopiar = new JMenuItem("Copiar");
        JMenuItem itemPegar = new JMenuItem("Pegar");
        JMenuItem itemBuscar = new JMenuItem("Buscar...");
        
        menuEdicion.add(itemCortar);
        menuEdicion.add(itemCopiar);
        menuEdicion.add(itemPegar);
        menuEdicion.addSeparator();
        menuEdicion.add(itemBuscar);
        
       
        JMenu menuFormato = new JMenu("Formato");
        JMenu menuFuente = new JMenu("Fuente");
        JCheckBoxMenuItem itemWrap = new JCheckBoxMenuItem("Ajuste de línea");
        
        ButtonGroup grupoFuente = new ButtonGroup();
        JRadioButtonMenuItem itemMono = new JRadioButtonMenuItem("Monospaced", true);
        JRadioButtonMenuItem itemSerif = new JRadioButtonMenuItem("Serif");
        JRadioButtonMenuItem itemSansSerif = new JRadioButtonMenuItem("SansSerif");
        
        grupoFuente.add(itemMono);
        grupoFuente.add(itemSerif);
        grupoFuente.add(itemSansSerif);
        
        menuFuente.add(itemMono);
        menuFuente.add(itemSerif);
        menuFuente.add(itemSansSerif);
        
        menuFormato.add(menuFuente);
        menuFormato.addSeparator();
        menuFormato.add(itemWrap);
        
       
        itemNuevo.addActionListener(e -> nuevoDocumento());
        itemAbrir.addActionListener(e -> abrirArchivo());
        itemGuardar.addActionListener(e -> guardarArchivo());
        itemGuardarComo.addActionListener(e -> guardarArchivoComo());
        itemSalir.addActionListener(e -> System.exit(0));
        
        itemCortar.addActionListener(e -> areaTexto.cut());
        itemCopiar.addActionListener(e -> areaTexto.copy());
        itemPegar.addActionListener(e -> areaTexto.paste());
        
        itemMono.addActionListener(e -> areaTexto.setFont(new Font("Monospaced", Font.PLAIN, 14)));
        itemSerif.addActionListener(e -> areaTexto.setFont(new Font("Serif", Font.PLAIN, 14)));
        itemSansSerif.addActionListener(e -> areaTexto.setFont(new Font("SansSerif", Font.PLAIN, 14)));
        
        itemWrap.addActionListener(e -> {
            areaTexto.setLineWrap(itemWrap.isSelected());
            areaTexto.setWrapStyleWord(true);
        });
        
       
        menuBar.add(menuArchivo);
        menuBar.add(menuEdicion);
        menuBar.add(menuFormato);
        
        return menuBar;
    }
    
    private JToolBar crearBarraHerramientas() {
        JToolBar toolBar = new JToolBar();
        toolBar.setFloatable(false);
        
        
        JButton btnNuevo = new JButton(new ImageIcon("nuevo.png"));
        JButton btnAbrir = new JButton(new ImageIcon("abrir.png"));
        JButton btnGuardar = new JButton(new ImageIcon("guardar.png"));
        
        btnNuevo.setToolTipText("Nuevo documento");
        btnAbrir.setToolTipText("Abrir archivo");
        btnGuardar.setToolTipText("Guardar archivo");
        
       
        btnNuevo.addActionListener(e -> nuevoDocumento());
        btnAbrir.addActionListener(e -> abrirArchivo());
        btnGuardar.addActionListener(e -> guardarArchivo());
        
        toolBar.add(btnNuevo);
        toolBar.add(btnAbrir);
        toolBar.add(btnGuardar);
        toolBar.addSeparator();
        
        return toolBar;
    }
    
    private void nuevoDocumento() {
        areaTexto.setText("");
        archivoActual = null;
        frame.setTitle("Editor de Texto Avanzado");
    }
    
    private void abrirArchivo() {
        if (fileChooser.showOpenDialog(frame) == JFileChooser.APPROVE_OPTION) {
            archivoActual = fileChooser.getSelectedFile();
            try (BufferedReader reader = new BufferedReader(new FileReader(archivoActual))) {
                StringBuilder contenido = new StringBuilder();
                String linea;
                while ((linea = reader.readLine()) != null) {
                    contenido.append(linea).append("\n");
                }
                areaTexto.setText(contenido.toString());
                frame.setTitle("Editor: " + archivoActual.getName());
            } catch (IOException e) {
                JOptionPane.showMessageDialog(frame, "Error al leer el archivo", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private void guardarArchivo() {
        if (archivoActual == null) {
            guardarArchivoComo();
        } else {
            guardarArchivo(archivoActual);
        }
    }
    
    private void guardarArchivoComo() {
        if (fileChooser.showSaveDialog(frame) == JFileChooser.APPROVE_OPTION) {
            archivoActual = fileChooser.getSelectedFile();
            guardarArchivo(archivoActual);
        }
    }
    
    private void guardarArchivo(File archivo) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(archivo))) {
            writer.write(areaTexto.getText());
            frame.setTitle("Editor: " + archivo.getName());
            JOptionPane.showMessageDialog(frame, "Archivo guardado con éxito", "Información", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(frame, "Error al guardar el archivo", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new EditorTextoConMenu());
    }
}