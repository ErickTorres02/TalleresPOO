import javax.swing.*;
import java.awt.event.*;

public class ToggleButtonsEjemplo {
    private JFrame frame;
    private JToggleButton tbtnInstalacion, tbtnFormacion, tbtnAlimentacionBD;
    private JLabel etiPrecioInstalacion, etiPrecioFormacion, etiPrecioAlimentacionBD;
    private JTextField txtPrecioBase;
    private JButton btnCalcular;
    private JLabel etiTotal;

    public ToggleButtonsEjemplo() {
        frame = new JFrame("ToggleButtons Ejemplo");
        frame.setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.Y_AXIS));
        
        
        JLabel lblPrecioBase = new JLabel("Precio Base");
        txtPrecioBase = new JTextField(10);
        
       
        tbtnInstalacion = new JToggleButton("Instalación");
        etiPrecioInstalacion = new JLabel("40");
        
        tbtnFormacion = new JToggleButton("Formación");
        etiPrecioFormacion = new JLabel("200");
        
        tbtnAlimentacionBD = new JToggleButton("Alimentación BD");
        etiPrecioAlimentacionBD = new JLabel("200");
        
        
        tbtnInstalacion.setSelected(true);
        
      
        btnCalcular = new JButton("Calcular");
        
       
        etiTotal = new JLabel("0 €");
        etiTotal.setBorder(BorderFactory.createEtchedBorder());
        etiTotal.setFont(etiTotal.getFont().deriveFont(16f));
        
       
        btnCalcular.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    double precioBase = Double.parseDouble(txtPrecioBase.getText());
                    double precioInstal = Double.parseDouble(etiPrecioInstalacion.getText());
                    double precioFor = Double.parseDouble(etiPrecioFormacion.getText());
                    double precioAli = Double.parseDouble(etiPrecioAlimentacionBD.getText());
                    
                    double precioTotal = precioBase;
                    
                    if (tbtnInstalacion.isSelected()) precioTotal += precioInstal;
                    if (tbtnFormacion.isSelected()) precioTotal += precioFor;
                    if (tbtnAlimentacionBD.isSelected()) precioTotal += precioAli;
                    
                    etiTotal.setText(precioTotal + " €");
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Por favor, ingrese un precio base válido.");
                }
            }
        });
        
      
        frame.add(lblPrecioBase);
        frame.add(txtPrecioBase);
        frame.add(tbtnInstalacion);
        frame.add(etiPrecioInstalacion);
        frame.add(tbtnFormacion);
        frame.add(etiPrecioFormacion);
        frame.add(tbtnAlimentacionBD);
        frame.add(etiPrecioAlimentacionBD);
        frame.add(btnCalcular);
        frame.add(etiTotal);
        
        frame.setSize(300, 350);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new ToggleButtonsEjemplo();
    }
}