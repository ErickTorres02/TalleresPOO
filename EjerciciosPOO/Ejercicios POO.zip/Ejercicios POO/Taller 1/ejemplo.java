import java.awt.*;
import java.awt.image.*;
import java.io.*;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;

public class ejemplo{
    private JFrame frame;
    private JLabel lblImagen;
    private JButton btnAbrir, btnGuardar, btnFiltros;
    private JFileChooser fileChooser;
    private BufferedImage imagenOriginal, imagenActual;

    public ejemplo() {
        frame = new JFrame("Visor Avanzado de Imágenes");
        frame.setLayout(new BorderLayout());
        
        // Configurar el file chooser
        fileChooser = new JFileChooser();
        FileNameExtensionFilter filter = new FileNameExtensionFilter(
            "Imágenes (JPG, PNG, GIF)", "jpg", "jpeg", "png", "gif");
        fileChooser.setFileFilter(filter);
        
        // Panel para la imagen
        lblImagen = new JLabel("Seleccione una imagen", JLabel.CENTER);
        lblImagen.setPreferredSize(new Dimension(800, 600));
        lblImagen.setBorder(BorderFactory.createLineBorder(Color.GRAY, 2));
        
        // Panel de botones
        JPanel panelBotones = new JPanel();
        btnAbrir = new JButton("Abrir Imagen");
        btnGuardar = new JButton("Guardar Imagen");
        btnFiltros = new JButton("Aplicar Filtros");
        
        btnGuardar.setEnabled(false);
        btnFiltros.setEnabled(false);
        
        panelBotones.add(btnAbrir);
        panelBotones.add(btnGuardar);
        panelBotones.add(btnFiltros);
        
        // Configurar acciones
        btnAbrir.addActionListener(e -> abrirImagen());
        btnGuardar.addActionListener(e -> guardarImagen());
        btnFiltros.addActionListener(e -> mostrarMenuFiltros());
        
        // Añadir componentes
        frame.add(lblImagen, BorderLayout.CENTER);
        frame.add(panelBotones, BorderLayout.SOUTH);
        
        // Configurar ventana
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
    
    private void abrirImagen() {
        if (fileChooser.showOpenDialog(frame) == JFileChooser.APPROVE_OPTION) {
            try {
                imagenOriginal = ImageIO.read(fileChooser.getSelectedFile());
                imagenActual = imagenOriginal;
                mostrarImagen();
                btnGuardar.setEnabled(true);
                btnFiltros.setEnabled(true);
            } catch (IOException e) {
                JOptionPane.showMessageDialog(frame, "Error al cargar la imagen", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private void guardarImagen() {
        if (imagenActual != null) {
            fileChooser.setDialogTitle("Guardar imagen como...");
            if (fileChooser.showSaveDialog(frame) == JFileChooser.APPROVE_OPTION) {
                try {
                    File archivo = fileChooser.getSelectedFile();
                    String nombre = archivo.getName().toLowerCase();
                    
                    // Asegurar la extensión correcta
                    if (!nombre.endsWith(".jpg") && !nombre.endsWith(".jpeg") && 
                        !nombre.endsWith(".png") && !nombre.endsWith(".gif")) {
                        archivo = new File(archivo.getAbsolutePath() + ".jpg");
                    }
                    
                    ImageIO.write(imagenActual, "jpg", archivo);
                    JOptionPane.showMessageDialog(frame, "Imagen guardada con éxito", "Información", JOptionPane.INFORMATION_MESSAGE);
                } catch (IOException e) {
                    JOptionPane.showMessageDialog(frame, "Error al guardar la imagen", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }
    
    private void mostrarMenuFiltros() {
        JPopupMenu menuFiltros = new JPopupMenu();
        
        JMenuItem itemEscalaGrises = new JMenuItem("Escala de grises");
        JMenuItem itemNegativo = new JMenuItem("Negativo");
        JMenuItem itemSepia = new JMenuItem("Sepia");
        JMenuItem itemBrillo = new JMenuItem("Aumentar brillo");
        JMenuItem itemOscuro = new JMenuItem("Oscurecer");
        JMenuItem itemOriginal = new JMenuItem("Restaurar original");
        
        menuFiltros.add(itemEscalaGrises);
        menuFiltros.add(itemNegativo);
        menuFiltros.add(itemSepia);
        menuFiltros.addSeparator();
        menuFiltros.add(itemBrillo);
        menuFiltros.add(itemOscuro);
        menuFiltros.addSeparator();
        menuFiltros.add(itemOriginal);
        
        // Configurar acciones
        itemEscalaGrises.addActionListener(e -> aplicarFiltro(1));
        itemNegativo.addActionListener(e -> aplicarFiltro(2));
        itemSepia.addActionListener(e -> aplicarFiltro(3));
        itemBrillo.addActionListener(e -> aplicarFiltro(4));
        itemOscuro.addActionListener(e -> aplicarFiltro(5));
        itemOriginal.addActionListener(e -> {
            imagenActual = imagenOriginal;
            mostrarImagen();
        });
        
        menuFiltros.show(btnFiltros, 0, btnFiltros.getHeight());
    }
    
    private void aplicarFiltro(int tipo) {
        if (imagenActual == null) return;
        
        int width = imagenActual.getWidth();
        int height = imagenActual.getHeight();
        BufferedImage nuevaImagen = new BufferedImage(width, height, imagenActual.getType());
        
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                Color color = new Color(imagenActual.getRGB(x, y));
                int r = color.getRed();
                int g = color.getGreen();
                int b = color.getBlue();
                
                switch (tipo) {
                    case 1: // Escala de grises
                        int gris = (int)(r * 0.299 + g * 0.587 + b * 0.114);
                        nuevaImagen.setRGB(x, y, new Color(gris, gris, gris).getRGB());
                        break;
                    case 2: // Negativo
                        nuevaImagen.setRGB(x, y, new Color(255-r, 255-g, 255-b).getRGB());
                        break;
                    case 3: // Sepia
                        int tr = (int)(0.393 * r + 0.769 * g + 0.189 * b);
                        int tg = (int)(0.349 * r + 0.686 * g + 0.168 * b);
                        int tb = (int)(0.272 * r + 0.534 * g + 0.131 * b);
                        nuevaImagen.setRGB(x, y, new Color(
                            Math.min(255, tr), 
                            Math.min(255, tg), 
                            Math.min(255, tb)).getRGB());
                        break;
                    case 4: // Brillo
                        nuevaImagen.setRGB(x, y, new Color(
                            Math.min(255, r+30), 
                            Math.min(255, g+30), 
                            Math.min(255, b+30)).getRGB());
                        break;
                    case 5: // Oscuro
                        nuevaImagen.setRGB(x, y, new Color(
                            Math.max(0, r-30), 
                            Math.max(0, g-30), 
                            Math.max(0, b-30)).getRGB());
                        break;
                }
            }
        }
        
        imagenActual = nuevaImagen;
        mostrarImagen();
    }
    
    private void mostrarImagen() {
        if (imagenActual != null) {
            ImageIcon icono = new ImageIcon(escalarImagen(imagenActual, 
                lblImagen.getWidth(), lblImagen.getHeight()));
            lblImagen.setIcon(icono);
            lblImagen.setText("");
        }
    }
    
    private Image escalarImagen(BufferedImage imagen, int ancho, int alto) {
        double escala = Math.min(
            (double)ancho / imagen.getWidth(), 
            (double)alto / imagen.getHeight());
        
        int nuevoAncho = (int)(imagen.getWidth() * escala);
        int nuevoAlto = (int)(imagen.getHeight() * escala);
        
        return imagen.getScaledInstance(nuevoAncho, nuevoAlto, Image.SCALE_SMOOTH);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ejemplo());
    }
}