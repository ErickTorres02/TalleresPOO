import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class SelectorFechaHora {
    private JFrame frame;
    private JSpinner spinnerFecha, spinnerHora;
    private JLabel lblResultado;

    public SelectorFechaHora() {
        frame = new JFrame("Selector Avanzado de Fecha y Hora");
        frame.setLayout(new GridLayout(3, 1, 10, 10));
        
        // Configurar spinner de fecha
        spinnerFecha = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor fechaEditor = new JSpinner.DateEditor(spinnerFecha, "dd/MM/yyyy");
        spinnerFecha.setEditor(fechaEditor);
        
        // Configurar spinner de hora
        spinnerHora = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor horaEditor = new JSpinner.DateEditor(spinnerHora, "HH:mm:ss");
        spinnerHora.setEditor(horaEditor);
        spinnerHora.setValue(new Date()); // Hora actual
        
        // Etiqueta para mostrar resultado
        lblResultado = new JLabel("", JLabel.CENTER);
        lblResultado.setFont(new Font("Arial", Font.BOLD, 16));
        lblResultado.setBorder(BorderFactory.createLineBorder(Color.BLUE, 2));
        
        // Configurar listener para ambos spinners
        ChangeListener listener = new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                actualizarResultado();
            }
        };
        spinnerFecha.addChangeListener(listener);
        spinnerHora.addChangeListener(listener);
        
        // Añadir componentes
        frame.add(new JLabel("Seleccione una fecha:", JLabel.CENTER));
        frame.add(spinnerFecha);
        frame.add(new JLabel("Seleccione una hora:", JLabel.CENTER));
        frame.add(spinnerHora);
        frame.add(lblResultado);
        
        // Configurar ventana
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(350, 250);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        
        actualizarResultado();
    }
    
    private void actualizarResultado() {
        try {
            Date fecha = (Date) spinnerFecha.getValue();
            Date hora = (Date) spinnerHora.getValue();
            
            Calendar calFecha = Calendar.getInstance();
            calFecha.setTime(fecha);
            
            Calendar calHora = Calendar.getInstance();
            calHora.setTime(hora);
            
            // Combinar fecha y hora
            calFecha.set(Calendar.HOUR_OF_DAY, calHora.get(Calendar.HOUR_OF_DAY));
            calFecha.set(Calendar.MINUTE, calHora.get(Calendar.MINUTE));
            calFecha.set(Calendar.SECOND, calHora.get(Calendar.SECOND));
            
            SimpleDateFormat sdf = new SimpleDateFormat("EEEE, dd 'de' MMMM 'de' yyyy 'a las' HH:mm:ss");
            lblResultado.setText("<html><div style='text-align: center;'>Fecha seleccionada:<br>" + 
                               sdf.format(calFecha.getTime()) + "</div></html>");
        } catch (Exception e) {
            lblResultado.setText("Error al procesar fecha");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SelectorFechaHora());
    }
}