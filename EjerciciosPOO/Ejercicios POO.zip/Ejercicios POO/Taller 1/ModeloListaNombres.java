import javax.swing.*;
import java.awt.event.*;
import javax.swing.event.*;

public class ModeloListaNombres {
    private JFrame frame;
    private JList<String> lstNombres;
    private DefaultListModel<String> modelo;
    private JButton btnCurso1, btnCurso2, btnVaciar;
    private JLabel etiResultado;

    public ModeloListaNombres() {
        frame = new JFrame("Modelo de Lista");
        frame.setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.Y_AXIS));
        
        modelo = new DefaultListModel<>();
        lstNombres = new JList<>(modelo);
        lstNombres.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (lstNombres.getSelectedValue() != null) {
                    etiResultado.setText(lstNombres.getSelectedValue().toString());
                }
            }
        });
        
        JScrollPane scrollPane = new JScrollPane(lstNombres);
        
        btnCurso1 = new JButton("Curso 1");
        btnCurso2 = new JButton("Curso 2");
        btnVaciar = new JButton("Vaciar");
        
        etiResultado = new JLabel();
        etiResultado.setBorder(BorderFactory.createEtchedBorder());
        
        btnCurso1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                modelo.clear();
                modelo.addElement("Juan");
                modelo.addElement("María");
                modelo.addElement("Luis");
            }
        });
        
        btnCurso2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                modelo.clear();
                modelo.addElement("Ana");
                modelo.addElement("Marta");
                modelo.addElement("Jose");
            }
        });
        
        btnVaciar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                modelo.clear();
            }
        });
        
        frame.add(scrollPane);
        frame.add(btnCurso1);
        frame.add(btnCurso2);
        frame.add(btnVaciar);
        frame.add(etiResultado);
        
        frame.setSize(300, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new ModeloListaNombres();
    }
}