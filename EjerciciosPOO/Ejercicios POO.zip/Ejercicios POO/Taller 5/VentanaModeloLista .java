import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.awt.*;

public class VentanaModeloLista extends JFrame {

    private JScrollPane scrollPane;
    private JList<String> lstNombres;
    private JButton btnCurso1;
    private JButton btnCurso2;
    private JButton btnVaciar;
    private JLabel etiResultado;

    public VentanaModeloLista() {
        initComponents();
    }

    private void initComponents() {
        lstNombres = new JList<>();
        scrollPane = new JScrollPane(lstNombres);
        btnCurso1 = new JButton("Curso 1");
        btnCurso2 = new JButton("Curso 2");
        btnVaciar = new JButton("Vaciar");
        etiResultado = new JLabel(" ");

        btnCurso1.addActionListener(e -> cargarCurso1());
        btnCurso2.addActionListener(e -> cargarCurso2());
        btnVaciar.addActionListener(e -> vaciarLista());
        lstNombres.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                etiResultado.setText(lstNombres.getSelectedValue().toString());
            }
        });

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Modelos en JList");
        setLayout(null);

        scrollPane.setBounds(20, 20, 120, 100);
        btnCurso1.setBounds(160, 20, 100, 30);
        btnCurso2.setBounds(160, 60, 100, 30);
        btnVaciar.setBounds(160, 100, 100, 30);
        etiResultado.setBounds(20, 140, 240, 30);
        etiResultado.setBorder(BorderFactory.createEtchedBorder());

        add(scrollPane);
        add(btnCurso1);
        add(btnCurso2);
        add(btnVaciar);
        add(etiResultado);

        setSize(320, 230);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void cargarCurso1() {
        DefaultListModel<String> modelo = new DefaultListModel<>();
        modelo.addElement("Juan");
        modelo.addElement("María");
        modelo.addElement("Luis");
        lstNombres.setModel(modelo);
    }

    private void cargarCurso2() {
        DefaultListModel<String> modelo = new DefaultListModel<>();
        modelo.addElement("Ana");
        modelo.addElement("Marta");
        modelo.addElement("Jose");
        lstNombres.setModel(modelo);
    }

    private void vaciarLista() {
        DefaultListModel<String> modelo = new DefaultListModel<>();
        lstNombres.setModel(modelo);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new VentanaModeloLista());
    }
}
