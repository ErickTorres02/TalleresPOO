import java.awt.*;
import javax.swing.*;

public class EjercicioPOO extends JFrame {
    private JButton btnAceptar;
    private JButton btnCancelar;

    public EjercicioPOO() {
        setTitle("Ejercicio POO");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        btnAceptar = new JButton("Aceptar");
        btnCancelar = new JButton("Cancelar");

        btnAceptar.setBackground(Color.GREEN);
        btnAceptar.setForeground(Color.WHITE);
        btnAceptar.setFont(new Font("Arial", Font.BOLD, 14));
        btnAceptar.setToolTipText("Presione para aceptar");

        btnCancelar.setBackground(Color.RED);
        btnCancelar.setForeground(Color.WHITE);
        btnCancelar.setFont(new Font("Arial", Font.BOLD, 14));
        btnCancelar.setToolTipText("Presione para cancelar");

        add(btnAceptar);
        add(btnCancelar);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            EjercicioPOO ventana = new EjercicioPOO();
            ventana.setVisible(true);
        });
    }
}