import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class MenuEmergente extends JFrame {
    private JPopupMenu menuEmergente;
    private JMenuItem menuRojo, menuVerde, menuAzul;

    public MenuEmergente() {
        setTitle("Ejercicio con Menú Emergente");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(Color.WHITE);

        menuEmergente = new JPopupMenu();
        
        menuRojo = new JMenuItem("Rojo");
        menuVerde = new JMenuItem("Verde");
        menuAzul = new JMenuItem("Azul");
        
        menuEmergente.add(menuRojo);
        menuEmergente.add(menuVerde);
        menuEmergente.add(menuAzul);

        menuRojo.addActionListener(e -> getContentPane().setBackground(Color.RED));
        menuVerde.addActionListener(e -> getContentPane().setBackground(Color.GREEN));
        menuAzul.addActionListener(e -> getContentPane().setBackground(Color.BLUE));

        addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                if (evt.getButton() == MouseEvent.BUTTON3) {
                    menuEmergente.show(evt.getComponent(), evt.getX(), evt.getY());
                }
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MenuEmergente ventana = new MenuEmergente();
            ventana.setVisible(true);
        });
    }
}