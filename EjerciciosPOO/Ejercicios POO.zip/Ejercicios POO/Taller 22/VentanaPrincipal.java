
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class VentanaPrincipal extends JFrame {
    private JLabel lblNum1, lblNum2;
    private JTextField txtNum1, txtNum2;
    private JButton btnSumar, btnRestar;

    public VentanaPrincipal() {
        initComponents();
        crearVentana();
        configurarEventos();
    }

    private void crearVentana() {
       
        setTitle("Calculadora Básica");
        setSize(350, 200);
        setLocationRelativeTo(null); // Centrar ventana
        setLayout(null);

        
        lblNum1 = new JLabel("Número 1:");
        lblNum1.setBounds(20, 20, 80, 20);
        add(lblNum1);

        lblNum2 = new JLabel("Número 2:");
        lblNum2.setBounds(20, 50, 80, 20);
        add(lblNum2);

        
        txtNum1 = new JTextField("0");
        txtNum1.setBounds(110, 20, 100, 20);
        add(txtNum1);

        txtNum2 = new JTextField("0");
        txtNum2.setBounds(110, 50, 100, 20);
        add(txtNum2);

       
        btnSumar = new JButton("Sumar");
        btnSumar.setBounds(20, 90, 100, 30);
        add(btnSumar);

        btnRestar = new JButton("Restar");
        btnRestar.setBounds(130, 90, 100, 30);
        add(btnRestar);
    }

    private void configurarEventos() {
        
        btnSumar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                calcularSuma();
            }
        });

       
        btnRestar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                calcularResta();
            }
        });
    }

    private void calcularSuma() {
        try {
            double num1 = Double.parseDouble(txtNum1.getText());
            double num2 = Double.parseDouble(txtNum2.getText());
            double resultado = num1 + num2;
            mostrarResultado("La suma es: " + resultado);
        } catch (NumberFormatException ex) {
            mostrarError("Debe ingresar números válidos");
        }
    }

    private void calcularResta() {
        try {
            double num1 = Double.parseDouble(txtNum1.getText());
            double num2 = Double.parseDouble(txtNum2.getText());
            double resultado = num1 - num2;
            mostrarResultado("La resta es: " + resultado);
        } catch (NumberFormatException ex) {
            mostrarError("Debe ingresar números válidos");
        }
    }

    private void mostrarResultado(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Resultado", JOptionPane.INFORMATION_MESSAGE);
    }

    private void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {
        // Código generado automáticamente por NetBeans
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new VentanaPrincipal().setVisible(true);
        });
    }
}