import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class BotonesVector extends JFrame {
    private JButton[] vbotones;

    public BotonesVector() {
        setTitle("Vector de Botones con Eventos");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        
        CreacionVentana();
    }

    private void CreacionVentana() {
        String[] textos = {"Botón 1", "Botón 2", "Botón 3", "Botón 4", "Botón 5"};
        vbotones = new JButton[5];
        
        for(int i = 0; i < vbotones.length; i++) {
            vbotones[i] = new JButton(textos[i]);
            vbotones[i].setBounds(50, 30 + i * 50, 200, 30);
            add(vbotones[i]);
            
            final int index = i;
            vbotones[i].addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent evt) {
                    botonesActionPerformed(evt);
                }
            });
        }
    }

    private void botonesActionPerformed(ActionEvent evt) {
        JButton botonPulsado = (JButton) evt.getSource();
        JOptionPane.showMessageDialog(this, "Has pulsado: " + botonPulsado.getText());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                BotonesVector ventana = new BotonesVector();
                ventana.setVisible(true);
            }
        });
    }
}