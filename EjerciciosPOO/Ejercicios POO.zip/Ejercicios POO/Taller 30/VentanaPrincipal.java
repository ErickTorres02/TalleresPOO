import java.awt.*;
import javax.swing.*;


public class VentanaPrincipal extends JFrame {
    private SalaCine central = new SalaCine();
    private SalaCine vo = new SalaCine();
    
    private JButton btnCentralNueva;
    private JButton btnCentralOcupacion;
    private JButton btnCentralVaciar;
    private JButton btnCentralIngresos;
    private JButton btnCentralCambiar;
    private JLabel etiCentralPelicula;
    private JLabel etiOriginalPelicula;
    private JPanel panelCentral;
    private JPanel panelVOriginal;
    private JButton btnOriginalNueva;
    private JButton btnOriginalOcupacion;
    private JButton btnOriginalVaciar;
    private JButton btnOriginalIngresos;
    private JButton btnOriginalCambiar;
    private JButton btnIngresosTotales;

    public VentanaPrincipal() {
        setTitle("Cine Colombia");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));
        
        central.setAforo(500);
        central.setEntrada(25000.0);
        vo.setAforo(80);
        vo.setEntrada(18000.0);
        
        initComponents();
        configurarEventos();
    }
    
    private void initComponents() {
        panelCentral = new JPanel(new FlowLayout());
        panelVOriginal = new JPanel(new FlowLayout());
        
        etiCentralPelicula = new JLabel("Sin película");
        etiOriginalPelicula = new JLabel("Sin película");
        
        btnCentralCambiar = new JButton("Cambiar Película");
        btnCentralNueva = new JButton("Vender Entrada");
        btnCentralOcupacion = new JButton("Ocupación");
        btnCentralVaciar = new JButton("Vaciar Sala");
        btnCentralIngresos = new JButton("Ver Ingresos");
        
        btnOriginalCambiar = new JButton("Cambiar Película");
        btnOriginalNueva = new JButton("Vender Entrada");
        btnOriginalOcupacion = new JButton("Ocupación");
        btnOriginalVaciar = new JButton("Vaciar Sala");
        btnOriginalIngresos = new JButton("Ver Ingresos");
        
        btnIngresosTotales = new JButton("Ingresos Totales");
        
        panelCentral.add(new JLabel("Sala Principal:"));
        panelCentral.add(etiCentralPelicula);
        panelCentral.add(btnCentralCambiar);
        panelCentral.add(btnCentralNueva);
        panelCentral.add(btnCentralOcupacion);
        panelCentral.add(btnCentralVaciar);
        panelCentral.add(btnCentralIngresos);
        
        panelVOriginal.add(new JLabel("Sala V.O.:"));
        panelVOriginal.add(etiOriginalPelicula);
        panelVOriginal.add(btnOriginalCambiar);
        panelVOriginal.add(btnOriginalNueva);
        panelVOriginal.add(btnOriginalOcupacion);
        panelVOriginal.add(btnOriginalVaciar);
        panelVOriginal.add(btnOriginalIngresos);
        
        add(panelCentral);
        add(panelVOriginal);
        add(btnIngresosTotales);
    }
    
    private void configurarEventos() {
        btnCentralCambiar.addActionListener(e -> {
            String titulo = JOptionPane.showInputDialog("Título de la película:");
            if (titulo != null && !titulo.isEmpty()) {
                central.setPelicula(titulo);
                etiCentralPelicula.setText(titulo);
            }
        });
        
        btnCentralNueva.addActionListener(e -> {
            central.entraUno();
            JOptionPane.showMessageDialog(this, "Entrada vendida: $25,000");
        });
        
        btnCentralOcupacion.addActionListener(e -> {
            String info = "Película: " + central.getPelicula() + "\n" +
                         "Butacas: " + central.getOcupadas() + "/" + central.getAforo() + "\n" +
                         "Ocupación: " + String.format("%.1f", central.getPorcentaje()) + "%";
            JOptionPane.showMessageDialog(this, info);
        });
        
        btnCentralVaciar.addActionListener(e -> {
            central.vaciar();
            etiCentralPelicula.setText("Sin película");
            JOptionPane.showMessageDialog(this, "Sala principal vaciada");
        });
        
        btnCentralIngresos.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, 
                "Ingresos: $" + String.format("%,.0f", central.getIngresos()));
        });
        
        btnOriginalCambiar.addActionListener(e -> {
            String titulo = JOptionPane.showInputDialog("Título de la película:");
            if (titulo != null && !titulo.isEmpty()) {
                vo.setPelicula(titulo);
                etiOriginalPelicula.setText(titulo);
            }
        });
        
        btnOriginalNueva.addActionListener(e -> {
            vo.entraUno();
            JOptionPane.showMessageDialog(this, "Entrada vendida: $18,000");
        });
        
        btnOriginalOcupacion.addActionListener(e -> {
            String info = "Película: " + vo.getPelicula() + "\n" +
                         "Butacas: " + vo.getOcupadas() + "/" + vo.getAforo() + "\n" +
                         "Ocupación: " + String.format("%.1f", vo.getPorcentaje()) + "%";
            JOptionPane.showMessageDialog(this, info);
        });
        
        btnOriginalVaciar.addActionListener(e -> {
            vo.vaciar();
            etiOriginalPelicula.setText("Sin película");
            JOptionPane.showMessageDialog(this, "Sala V.O. vaciada");
        });
        
        btnOriginalIngresos.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, 
                "Ingresos: $" + String.format("%,.0f", vo.getIngresos()));
        });
        
        btnIngresosTotales.addActionListener(e -> {
            double total = central.getIngresos() + vo.getIngresos();
            JOptionPane.showMessageDialog(this, 
                "Ingresos totales: $" + String.format("%,.0f", total));
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            VentanaPrincipal ventana = new VentanaPrincipal();
            ventana.setVisible(true);
        });
    }
}