public class SalaCine {
    
    private int aforo;
    private int ocupadas;
    private String pelicula;
    private double entrada;

   
    public SalaCine() {
        this.aforo = 100;
        this.ocupadas = 0;
        this.pelicula = "";
        this.entrada = 5.0;
    }

    
    public void setAforo(int aforo) {
        this.aforo = aforo;
    }

    public void setOcupadas(int ocupadas) {
        this.ocupadas = ocupadas;
    }

    public void setLibres(int libres) {
        this.ocupadas = this.aforo - libres;
    }

    public void setPelicula(String pelicula) {
        this.pelicula = pelicula;
    }

    public void setEntrada(double entrada) {
        this.entrada = entrada;
    }

    
    public int getAforo() {
        return aforo;
    }

    public int getOcupadas() {
        return ocupadas;
    }

    public int getLibres() {
        return aforo - ocupadas;
    }

    public double getPorcentaje() {
        return (ocupadas * 100.0) / aforo;
    }

    public double getIngresos() {
        return ocupadas * entrada;
    }

    public String getPelicula() {
        return pelicula;
    }

    public double getEntrada() {
        return entrada;
    }

   
    public void vaciar() {
        ocupadas = 0;
        pelicula = "";
    }

    public void entraUno() {
        if (ocupadas < aforo) {
            ocupadas++;
        }
    }
}