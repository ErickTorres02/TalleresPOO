import java.awt.*;
import javax.swing.*;

public class EjercicioFileChooser extends JFrame {
    private JMenuBar barraMenus;
    private JMenu menuArchivo;
    private JMenuItem menuAbrir, menuSalir;
    private JFileChooser elegirFichero;

    public EjercicioFileChooser() {
        setTitle("Ejercicio con JFileChooser");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        barraMenus = new JMenuBar();
        setJMenuBar(barraMenus);

        menuArchivo = new JMenu("Archivo");
        barraMenus.add(menuArchivo);

        menuAbrir = new JMenuItem("Abrir");
        menuSalir = new JMenuItem("Salir");

        menuArchivo.add(menuAbrir);
        menuArchivo.addSeparator();
        menuArchivo.add(menuSalir);

        elegirFichero = new JFileChooser();

        menuAbrir.addActionListener(e -> {
            int resp = elegirFichero.showOpenDialog(this);
            if (resp == JFileChooser.APPROVE_OPTION) {
                JOptionPane.showMessageDialog(this, 
                    "Fichero seleccionado: " + 
                    elegirFichero.getSelectedFile().getAbsolutePath());
            } else if (resp == JFileChooser.CANCEL_OPTION) {
                JOptionPane.showMessageDialog(this, "Operación cancelada");
            }
        });

        menuSalir.addActionListener(e -> System.exit(0));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            EjercicioFileChooser ventana = new EjercicioFileChooser();
            ventana.setVisible(true);
        });
    }
}