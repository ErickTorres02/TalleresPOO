import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;

public class EjercicioSliders extends JFrame {
    private JSlider slDeslizador;
    private JLabel etiValor;

    public EjercicioSliders() {
        // Configuración básica de la ventana
        setTitle("Ejercicio con JSlider");
        setSize(500, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(new Color(240, 240, 240));

        // Creación del JSlider con las propiedades solicitadas
        slDeslizador = new JSlider(JSlider.HORIZONTAL, 100, 500, 400);
        
        // Configuración del JSlider
        slDeslizador.setMajorTickSpacing(50);
        slDeslizador.setMinorTickSpacing(10);
        slDeslizador.setPaintTicks(true);
        slDeslizador.setPaintLabels(true);
        slDeslizador.setPaintTrack(true);
        slDeslizador.setSnapToTicks(false);
        
        // Cambiar el color de las marcas y etiquetas para mejor visibilidad
        slDeslizador.setForeground(new Color(70, 70, 70));

        // Creación de la etiqueta con borde
        etiValor = new JLabel("El valor es: 400", SwingConstants.CENTER);
        etiValor.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        etiValor.setFont(new Font("Arial", Font.BOLD, 14));
        etiValor.setOpaque(true);
        etiValor.setBackground(Color.WHITE);

        // Añadir componentes a la ventana
        add(slDeslizador, BorderLayout.CENTER);
        add(etiValor, BorderLayout.SOUTH);

        // Añadir listener para el cambio de valor del slider
        slDeslizador.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                etiValor.setText("El valor es: " + slDeslizador.getValue());
            }
        });

        // Añadir padding alrededor de los componentes
        ((JComponent) getContentPane()).setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            EjercicioSliders ventana = new EjercicioSliders();
            ventana.setVisible(true);
        });
    }
}