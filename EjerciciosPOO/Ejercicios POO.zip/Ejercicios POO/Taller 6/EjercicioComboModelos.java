import javax.swing.*;
import javax.swing.DefaultComboBoxModel;
import java.awt.*;
import java.awt.event.*;

public class EjercicioComboModelos extends JFrame implements ActionListener {
    private JComboBox<String> cboNumeros;
    private JButton btnPares, btnImpares, btnVaciar;
    private JLabel etiResultado;

    public EjercicioComboModelos() {
        // Configuración básica de la ventana
        setTitle("Ejercicio Modelos de Combo");
        setSize(300, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        // Creación de los componentes
        cboNumeros = new JComboBox<>();
        btnPares = new JButton("Pares");
        btnImpares = new JButton("Impares");
        btnVaciar = new JButton("Vaciar");
        etiResultado = new JLabel("Resultado aparecerá aquí");
        etiResultado.setBorder(BorderFactory.createLineBorder(Color.BLACK));

        // Añadir componentes a la ventana
        add(cboNumeros);
        add(btnPares);
        add(btnImpares);
        add(btnVaciar);
        add(etiResultado);

        // Asignar listeners
        btnPares.addActionListener(this);
        btnImpares.addActionListener(this);
        btnVaciar.addActionListener(this);
        cboNumeros.addActionListener(this);

        // Inicializar el combo vacío
        vaciarCombo();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnPares) {
            DefaultComboBoxModel<String> modelo = new DefaultComboBoxModel<>();
            for (int i = 0; i < 10; i += 2) {
                modelo.addElement("Nº " + i);
            }
            cboNumeros.setModel(modelo);
        } else if (e.getSource() == btnImpares) {
            DefaultComboBoxModel<String> modelo = new DefaultComboBoxModel<>();
            for (int i = 1; i < 10; i += 2) {
                modelo.addElement("Nº " + i);
            }
            cboNumeros.setModel(modelo);
        } else if (e.getSource() == btnVaciar) {
            vaciarCombo();
        } else if (e.getSource() == cboNumeros) {
            if (cboNumeros.getSelectedItem() != null) {
                etiResultado.setText(cboNumeros.getSelectedItem().toString());
            }
        }
    }

    private void vaciarCombo() {
        DefaultComboBoxModel<String> modelo = new DefaultComboBoxModel<>();
        cboNumeros.setModel(modelo);
        etiResultado.setText("Combo vaciado");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            EjercicioComboModelos ventana = new EjercicioComboModelos();
            ventana.setVisible(true);
        });
    }
}