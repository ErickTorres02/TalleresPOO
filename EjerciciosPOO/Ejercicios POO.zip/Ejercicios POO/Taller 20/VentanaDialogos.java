import java.awt.*;
import javax.swing.*;

public class VentanaDialogos extends JFrame {
    private JTextField txtUnidades, txtPrecio;
    private JLabel etiTotal;
    private double iva = 0;
    private double descuento = 0;
    private JDialog dialogoConfiguracion;

    public VentanaDialogos() {
        setTitle("Calculadora de Ventas");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(4, 2, 10, 10));

        add(new JLabel("Unidades:"));
        txtUnidades = new JTextField("0");
        add(txtUnidades);

        add(new JLabel("Precio:"));
        txtPrecio = new JTextField("0");
        add(txtPrecio);

        add(new JLabel("Total:"));
        etiTotal = new JLabel("0");
        etiTotal.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        add(etiTotal);

        JButton btnCalcular = new JButton("Calcular");
        btnCalcular.addActionListener(e -> calcularTotal());
        add(btnCalcular);

        JButton btnConfiguracion = new JButton("Configuración");
        btnConfiguracion.addActionListener(e -> mostrarDialogoConfiguracion());
        add(btnConfiguracion);

        crearDialogoConfiguracion();
    }

    private void calcularTotal() {
        try {
            double unidades = Double.parseDouble(txtUnidades.getText());
            double precio = Double.parseDouble(txtPrecio.getText());
            double totalsiniva = precio * unidades;
            double cantiva = totalsiniva * iva / 100;
            double cantdes = totalsiniva * descuento / 100;
            double total = totalsiniva + cantiva - cantdes;
            etiTotal.setText(String.format("%.2f", total));
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Ingrese valores numéricos válidos");
        }
    }

    private void crearDialogoConfiguracion() {
        dialogoConfiguracion = new JDialog(this, "Configuración de IVA y Descuento", true);
        dialogoConfiguracion.setSize(250, 200);
        dialogoConfiguracion.setLayout(new GridLayout(3, 2, 10, 10));

        JTextField txtIva = new JTextField(String.valueOf(iva));
        JTextField txtDescuento = new JTextField(String.valueOf(descuento));

        dialogoConfiguracion.add(new JLabel("IVA (%):"));
        dialogoConfiguracion.add(txtIva);
        dialogoConfiguracion.add(new JLabel("Descuento (%):"));
        dialogoConfiguracion.add(txtDescuento);

        JButton btnAceptar = new JButton("Aceptar");
        btnAceptar.addActionListener(e -> {
            try {
                iva = Double.parseDouble(txtIva.getText());
                descuento = Double.parseDouble(txtDescuento.getText());
                dialogoConfiguracion.dispose();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialogoConfiguracion, "Ingrese valores numéricos válidos");
            }
        });
        dialogoConfiguracion.add(btnAceptar);

        JButton btnCancelar = new JButton("Cancelar");
        btnCancelar.addActionListener(e -> dialogoConfiguracion.dispose());
        dialogoConfiguracion.add(btnCancelar);
    }

    private void mostrarDialogoConfiguracion() {
        dialogoConfiguracion.setLocationRelativeTo(this);
        dialogoConfiguracion.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            VentanaDialogos ventana = new VentanaDialogos();
            ventana.setVisible(true);
        });
    }
}