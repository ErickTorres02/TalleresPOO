import java.awt.*;
import javax.swing.*;

public class EjercicioToolBar extends JFrame {
    private JMenuBar barraMenus;
    private JToolBar barraHerramientas;
    private JButton btnUno, btnDos, btnTres, btnCuatro;

    public EjercicioToolBar() {
        setTitle("Ejercicio con Barra de Herramientas");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(Color.WHITE);
        setLayout(new BorderLayout());

        barraMenus = new JMenuBar();
        setJMenuBar(barraMenus);

        barraHerramientas = new JToolBar();
        barraHerramientas.setFloatable(false);
        add(barraHerramientas, BorderLayout.NORTH);

        btnUno = new JButton();
        btnDos = new JButton();
        btnTres = new JButton();
        btnCuatro = new JButton();

        btnUno.setIcon(new ImageIcon("icono1.png"));
        btnDos.setIcon(new ImageIcon("icono2.png"));
        btnTres.setIcon(new ImageIcon("icono3.png"));
        btnCuatro.setIcon(new ImageIcon("icono4.png"));

        btnUno.setToolTipText("Botón Uno");
        btnDos.setToolTipText("Botón Dos");
        btnTres.setToolTipText("Botón Tres");
        btnCuatro.setToolTipText("Botón Cuatro");

        barraHerramientas.add(btnUno);
        barraHerramientas.add(btnDos);
        barraHerramientas.add(btnTres);
        barraHerramientas.add(btnCuatro);

        barraHerramientas.addSeparator();

        btnUno.addActionListener(e -> JOptionPane.showMessageDialog(this, "Botón Uno presionado"));
        btnDos.addActionListener(e -> JOptionPane.showMessageDialog(this, "Botón Dos presionado"));
        btnTres.addActionListener(e -> JOptionPane.showMessageDialog(this, "Botón Tres presionado"));
        btnCuatro.addActionListener(e -> JOptionPane.showMessageDialog(this, "Botón Cuatro presionado"));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            EjercicioToolBar ventana = new EjercicioToolBar();
            ventana.setVisible(true);
        });
    }
}