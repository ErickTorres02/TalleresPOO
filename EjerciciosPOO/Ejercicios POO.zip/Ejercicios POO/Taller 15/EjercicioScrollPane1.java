import javax.swing.*;

public class EjercicioScrollPane1 extends JFrame {
    private JScrollPane scpImagen;
    private JLabel etiImagen;

    public EjercicioScrollPane1() {
        setTitle("Panel de Desplazamiento con Imagen");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        etiImagen = new JLabel();
        etiImagen.setIcon(new ImageIcon("Nenufares.jpg"));
        
        scpImagen = new JScrollPane(etiImagen);
        add(scpImagen);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            EjercicioScrollPane1 ventana = new EjercicioScrollPane1();
            ventana.setVisible(true);
        });
    }
}