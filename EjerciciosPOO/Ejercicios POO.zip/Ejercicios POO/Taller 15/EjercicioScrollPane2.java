import javax.swing.*;
import javax.swing.*;

public class EjercicioScrollPane2 extends JFrame {
    private JScrollPane scpDatos;
    private JPanel panelDatos;

    public EjercicioScrollPane2() {
        setTitle("Panel de Desplazamiento con Formulario");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panelDatos = new JPanel();
        panelDatos.setBackground(new Color(200, 255, 200));
        panelDatos.setLayout(new GridLayout(8, 2, 10, 10));
        panelDatos.setPreferredSize(new Dimension(550, 700));

        panelDatos.add(new JLabel("Panel de Datos", SwingConstants.CENTER));
        panelDatos.add(new JLabel());
        
        String[] dias = {"Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"};
        for (String dia : dias) {
            panelDatos.add(new JLabel(dia));
            panelDatos.add(new JTextField());
        }

        scpDatos = new JScrollPane(panelDatos);
        add(scpDatos);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            EjercicioScrollPane2 ventana = new EjercicioScrollPane2();
            ventana.setVisible(true);
        });
    }
}