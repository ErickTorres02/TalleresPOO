package ventanas;

import javax.swing.*;

public class VentanaPrincipal extends JFrame {
    private JLabel etiNum1, etiNum2;
    private JTextField txtNum1, txtNum2;
    private JButton btnSumar, btnRestar;

    public VentanaPrincipal() {
        initComponents();
        CreacionVentana();
    }

    private void CreacionVentana() {
       
        this.setTitle("Operaciones Matemáticas");
        this.setSize(500, 300);
        this.setLocation(100, 100);
        this.setLayout(null); 

        
        etiNum1 = new JLabel();
        etiNum1.setText("Número 1:");
        etiNum1.setBounds(10, 10, 100, 20);
        this.getContentPane().add(etiNum1);

        etiNum2 = new JLabel();
        etiNum2.setText("Número 2:");
        etiNum2.setBounds(10, 60, 100, 20);
        this.getContentPane().add(etiNum2);

       
        txtNum1 = new JTextField();
        txtNum1.setText("0");
        txtNum1.setBounds(120, 10, 100, 20);
        this.getContentPane().add(txtNum1);

        txtNum2 = new JTextField();
        txtNum2.setText("0");
        txtNum2.setBounds(120, 60, 100, 20);
        this.getContentPane().add(txtNum2);

        
        btnSumar = new JButton();
        btnSumar.setText("Sumar");
        btnSumar.setBounds(10, 110, 100, 30);
        this.getContentPane().add(btnSumar);

        btnRestar = new JButton();
        btnRestar.setText("Restar");
        btnRestar.setBounds(120, 110, 100, 30);
        this.getContentPane().add(btnRestar);
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {
        
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            VentanaPrincipal ventana = new VentanaPrincipal();
            ventana.setVisible(true);
        });
    }
}